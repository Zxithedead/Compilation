<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

// show all errors
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
ini_set("track_errors", 1);
ini_set("html_errors", 1);
error_reporting(E_ALL);

require '../vendor/autoload.php';
require "../src/diskover/Diskover.php";


// get command line args
$docindex = $argv[1];
$docid = $argv[2];
$doctype = $argv[3];
$recursive = $argv[4];
$allindex = $argv[5];
$query = $argv[6];

$docindex_nocluster = $mnclient->getIndexNoCluster($docindex);

// get tags for doc id
$searchParams = [];
$searchParams['index'] = $docindex;
$searchParams['body'] = [
    'query' => [
        'ids' => [
            'type' => '_doc',
            'values' => [ $docid ]
        ]
    ]
];
$queryResponse = $client->search($searchParams);
$docsource = $queryResponse['hits']['hits'][0]['_source'];

$path = $docsource['parent_path'] . '/' . $docsource['name'];
// root
if ($path === "//") {
    $path = "/";
}

// tags we want to tag other docs with
$tags = $docsource['tags'];


// check if we are tagging all search query results or tagging directory docs
if (!isset($query)) {
    // diff query if root path /
    if ($path === '/') {
        if ($recursive == 'true') {
            $query = '(parent_path:\/ OR parent_path:\/*)';
        } else {
            $query = 'parent_path:\/';
        }
    } else {
        // escape special characters
        $path = escape_chars($path);
        if ($recursive == 'true') {
            $query = '(parent_path:' . $path . ' OR parent_path:' . $path . '\/*)';
        } else {
            $query = 'parent_path:' . $path;
        }
    }
    $doctype = ($doctype == 'all') ? '(file OR directory)' : $doctype;

    $searchParams = [
        'index' => $docindex,
        'scroll' => "1m",
        'size' => 1000,
        'body' => [
            'query' => [
                'query_string' => [
                    'query' => $query . ' AND type:' . $doctype,
                    'analyze_wildcard' => 'true'
                ]
            ]
        ]
    ];
} else {
    $searchParams = [
        'index' => $allindex,
        'scroll' => "1m",
        'size' => 1000,
        'body' => [
            'query' => [
                'query_string' => [
                    'query' => rawurldecode($query),
                    'analyze_wildcard' => 'true'
                ]
            ]
        ]
    ];
}

var_dump($searchParams);

$queryResponse = $client->search($searchParams);

// Get the first scroll_id
$scroll_id = $queryResponse['_scroll_id'];

// update tags for all matching docs (bulk update)
$multi_params = ['body' => []];

$docsupdated = 0;

// Loop through all the pages of results and update their doc tags field
while (isset($queryResponse['hits']['hits']) && count($queryResponse['hits']['hits']) > 0) {
    // Get results
    foreach ($queryResponse['hits']['hits'] as $hit) {
        $multi_params['body'][] = [
            'update' => [
                '_index' => $hit['_index'],
                '_type' => '_doc',
                '_id' => $hit['_id']
            ]
        ];
        $hit['_source']['tags'] = $tags;
        $multi_params['body'][] = [
            'doc' => $hit['_source']
        ];

        $docsupdated += 1;

        // bulk upload every 1000 docs
        if ($docsupdated >= 1000) {
            $updateclient = $mnclient->getClientByIndex($docindex_nocluster);
            $result = $updateclient->bulk($multi_params);
            unset($result);
            unset($multi_params);
            $multi_params = ['body' => []];
            $docsupdated = 0;
        }
    }

    $scroll_id = $queryResponse['_scroll_id'];

    $queryResponse = $client->scroll([
        'body' => [
            "scroll_id" => $scroll_id,
            "scroll" => "1m"
        ]
    ]);
}

// update any remaining docs
if (count($multi_params['body']) > 0) {
    // refresh index
    $multi_params['refresh'] = true;
    $updateclient = $mnclient->getClientByIndex($docindex_nocluster);
    $result = $updateclient->bulk($multi_params);
}
?>