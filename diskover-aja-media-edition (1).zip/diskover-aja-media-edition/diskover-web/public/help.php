<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';
use diskover\Constants;
use Elasticsearch\Common\Exceptions\Missing404Exception;
error_reporting(E_ALL ^ E_NOTICE);
require "../src/diskover/Auth.php";
require "../src/diskover/Diskover.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-NDFBQ1BYMH');
    </script>
    <?php } ?>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>diskover &mdash; Help/ Support</title>
	<link rel="stylesheet" href="css/fontawesome-free/css/all.min.css" media="screen" />
	<link rel="stylesheet" href="css/bootswatch.min.css" media="screen" />
	<link rel="stylesheet" href="css/diskover.css" media="screen" />
	<link rel="icon" type="image/png" href="images/diskoverfavico.png" />
    <style>
    code {
        background-color:#333!important;
        color: #56B6C2!important;
    }
    strong {
        color: gray;
    }
    </style>
</head>
<body>
	<?php include "nav.php"; ?>

	<div class="container" id="mainwindow" style="margin-top:70px;">
		<h1 class="page-header"><i class="glyphicon glyphicon-question-sign"></i> Help/ Support</h1>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-dismissible alert-info">
                    <i class="glyphicon glyphicon-info-sign"></i> For support and discussions, please join the diskover <a href="https://join.slack.com/t/diskoverworkspace/shared_invite/enQtNzQ0NjE1Njk5MjIyLWI4NWQ0MjFhYzQyMTRhMzk4NTQ3YjBlYjJiMDk1YWUzMTZmZjI1MTdhYTA3NzAzNTU0MDc5NDA2ZDI4OWRiMjM" target="_blank" class="alert-link">Slack workspace</a>.<br>
					For any feedback/ issues, please submit an issue on <a href="https://github.com/diskoverdata/diskover-community/issues" target="_blank" class="alert-link">GitHub issues</a> page or email us at <a href="mailto:support@diskoverdata.com" target="_blank" class="alert-link">support@diskoverdata.com</a>.<br>
					Documentation is located at <a href="https://docs.diskoverdata.com" target="_blank" class="alert-link">docs.diskoverdata.com</a>.
                </div>
            </div>
        </div>
		<div class="row">
			<div class="col-xs-6">
				<div class="well">
					<h3>Search queries</h3>
					<ul>
						<li>By default use name, parent_path and extension fields when searching</li>
						<li>By default use AND when searching multiple words</li>
						<li>By default are case-insensitive</li>
						<li>Are case-sensitive when using field names except for name.text and parent_path.text</li>
						<li>By default wildcards are not used, to use wildcards use * or ?, example filename*</li>
						<li>Can be combined with AND, OR, NOT and ( ) round brackets for more granular search results (lowercase works as well)</li>
					</ul>
					<h4>Examples</h4>
					<p>all files > 5 MB:<br>
						<strong>size:>5242880 AND type:file</strong><br />
					<p>all folders > 10 MB:<br>
						<strong>size:>10485760 AND type:directory</strong><br />
					<p>all files in directory:<br>
						<strong>parent_path:"/Users/shirosai/Downloads"</strong><br />
					<p>all files in directory and all subdirs:<br>
						<strong>parent_path:\/Users\/shirosai\/Downloads*</strong><br />
					<p>files that haven't been modified in over 3 months and less than 5 years:<br>
						<strong>mtime:[now-5y TO now-3M]</strong><br />
					<p>files that haven't been modified or accessed in over 1 year:<br><strong>mtime:[* TO now-1y] AND atime:[* TO now-1y]</strong><br />
					<p>image files:<br>
						<strong>extension:(jpg OR gif OR png OR tif OR tiff OR dpx OR exr OR psd OR bmp OR tga)</strong><br />
					<p>audio files:<br>
						<strong>extension:(aif OR iff OR m3u OR m4a OR mid OR mp3 OR mpa OR wav OR wma)</strong><br />
					<p>video files:<br>
						<strong>extension:(asf OR avi OR flv OR m4v OR mov OR mp4 OR mpg OR rm OR vob OR wmv)</strong><br />
					<p>temp files:<br>
						<strong>extension:(cache OR tmp OR temp OR bak OR old)</strong><br />
					<p>compressed files:<br>
						<strong>extension:(7z OR deb OR gz OR pkg OR rar OR rpm OR tar OR zip OR zipx)</strong><br />
					<p>image sequence img001.dpx, img002.dpx, im003.dpx:<br>
						<strong>name:img*.dpx</strong><br />
					<p>all files or folders containing the word shirosai somewhere in the path (case-insensitive):<br>
						<strong>shirosai</strong><br />
					<p>all files or folders containing the word shirosai and diskover somewhere in the path (case-insensitive):<br>
						<strong>shirosai diskover</strong><br />
					<p>all files or folders containing the word shirosai or github somewhere in the path (case-insensitive):<br>
						<strong>shirosai OR github</strong><br />
					<p>all files containing the word shirosai in the file name (case-insensitive):<br>
						<strong>name.text:shirosai AND type:file</strong><br />
					<p>all folders containing the word shirosai in the folder name (case-insensitive):<br>
						<strong>name.text:shirosai AND type:directory</strong><br />
					<p>all files containing the word shirosai (case-sensitive):<br>
						<strong>name:*shirosai* AND type:file</strong><br />
					<p>all folders containing the word shirosai (case-sensitive):<br>
						<strong>name:*shirosai* AND type:directory</strong><br />
					<p>files named "shirosai.doc" with lowercase s:<br>
						<strong>name:shirosai.doc</strong><br />
					<p>files named "Shirosai.doc" with uppercase S:<br>
						<strong>name:Shirosai.doc</strong><br />
					<p>doc files with lowercase word "shirosai" at start of filename:<br>
						<strong>name:shirosai*.doc</strong><br />
					<p>doc files with lowercase word "shirosai" at end of filename:<br>
						<strong>name:*shirosai.doc</strong><br />
					<p>doc files with lowercase and first letter uppercase word "shirosai" somewhere in the filename:<br>
						<strong>name:(*shirosai*.doc OR *Shirosai*.doc)</strong><br />
					<p>files with lowercase "shirosai" somewhere in the filename or path:<br>
						<strong>(name:*shirosai* OR parent_path:*shirosai*) AND type:file</strong><br />
					<?php if ($_SESSION['license']['product_code'] == 'ESS') { echo '<p><span class="label label-info">Pro</span></p>'; } ?>
					<p>all files with tag "version 1":<br>
						<strong>#version 1</strong><br />
					<p>all files with tag "version 2" and larger than 10 MB:<br>
						<strong>tags:"version 2" AND size:>10485760 AND type:file</strong><br />
					<p>all files with tag "delete" and tag "cleanup":<br>
						<strong>tags:(delete AND cleanup)</strong>
					<p>all files with tag "delete" or tag "cleanup":<br>
						<strong>tags:(delete OR cleanup)</strong>
				</div>
				<div class="well">
                    <h3>Tagging files</h3>
					<?php if ($_SESSION['license']['product_code'] == 'ESS') { echo '<p><span class="label label-info">Pro</span></p>'; } ?>
    				<p>To tag files or directories perform a search and then on the results page use the checkboxes in the first column to select the items you want to tag. Once the items you want are selected, click the tag button <strong><i class="glyphicon glyphicon-tag"></i></strong>. From the drop-down menu you can select one of the tags or add a new tag. Tags are created with "<strong>tag name|#hexcolor</strong>" (no quotes). </p>
                    <p>You can remove a tag on the tag menu clicking the same tag again. You can also remove all tags with "Remove all tags" menu option.</p>
                    <p>Use the select all and unselect all buttons next to the tag button to select or unselect all items on the current search results page.</p>
                </div>
			</div>
			<div class="col-xs-6">
			<div class="well">
                    <h3>Default index fields</h3>
                    <p>Below are a list of index field names which can be used for searching using <strong>fieldname:value</strong>.</p>
					<p>All values are case-sensitive except for fields with the name .text in the name.</p>
					<ul>
					<?php
					foreach ($fields as $field) {
						echo "<li>" . $field . "</li>\n";
					}
					?>
					</ul>
				</div>
				<div class="well">
                    <h3>Smart search examples</h3>
                    <p>To start a smartsearch, press the "<strong>!</strong>" key or for paths use "<strong>/</strong>" in the search input. Smart searches can be edited on the Admin page.</p>
                    <p>To disable smartsearch and just use normal ES query, start the search with "<strong>\</strong>".</p>
					<p>all files in directory:<br>
						<strong>/Users/shirosai/Downloads</strong><br />
					<p>all files in directory and all subdirs:<br>
						<strong>/Users/shirosai/Downloads*</strong><br />
					<p>full path to file:<br>
						<strong>/Users/shirosai/Downloads/image.png</strong><br />
					<p>image files:<br>
						<strong>!img</strong><br />
					<p>audio files:<br>
						<strong>!aud</strong><br />
					<p>video files:<br>
						<strong>!vid</strong><br />
                    <p>document files:<br>
						<strong>!doc</strong><br />
					<p>temp files:<br>
						<strong>!tmp</strong><br />
					<p>compressed files:<br>
						<strong>!compress</strong><br />
                    <p>database files:<br>
						<strong>!datab</strong><br />
                    <p>disc image files:<br>
						<strong>!discimg</strong><br />
                    <p>executable files:<br>
						<strong>!exe</strong><br />
                    <p>web files:<br>
						<strong>!web</strong><br />
                    <p>code files:<br>
						<strong>!code</strong><br />
                    <p>system files:<br>
						<strong>!sys</strong><br />
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="well">
                    <h3>Rest API</h3>
					<h4>Get (with curl or web browser)</h4>
					<p>Getting file/directory tag info is done with the GET method.</p>
					<p>For "tags", and "search" endpoints, you can set the page number and result size with ex. &page=1 and &size=100. Default is page 1 and size 1000.</p>
					<p>Curl example:<br />
					<code>curl -X GET http://localhost:8000/api.php/indexname/endpoint</code></p>
					<p>List all diskover indices and stats for each:<br />
					<code>GET http://localhost:8000/api.php/list</code></p>
					<p>List all files with no tag (untagged):<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/tags?tag=&type=file</code></p>
                    <p>List all directories with no tag (untagged):<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/tags?tag=&type=directory</code></p>
					<p>List files with tag "version 1":<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/tags?tag=version%201&type=file</code></p>
                    <p>List directories with tag "version 1":<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/tags?tag=version%201&type=directory</code></p>
                    <p>List files/directories (all items) with tag "version 1":<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/tags?tag=version%201</code></p>
					<p>List files with tag "archive":<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/tags?tag=archive&type=file</code></p>
                    <p>List directories with tag "delete":<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/tags?tag=delete&type=directory</code></p>
					<p>List total size (in bytes) of files for each tag:<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/tagsize?type=file</code></p>
					<p>List total size (in bytes) of files with tag "delete":<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/tagsize?tag=delete&type=file</code></p>
					<p>List total size (in bytes) of files with tag "version 1":<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/tagsize?tag=version%201&type=file</code></p>
					<p>List total number of files for each tag:<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/tagcount?type=file</code></p>
					<p>List total number of files with tag "delete":<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/tagcount?tag=delete&type=file</code></p>
					<p>List total number of files with tag "version 1":<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/tagcount?tag=version+1&type=file</code></p>
					<p>Search index using ES query syntax:<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/search?query=extension:png%20AND%20type:file%20AND%20size:>1048576</code></p>
					<p>Get latest completed index using top path in index:<br />
					<code>GET http://localhost:8000/api.php/latest?toppath=/dirpath</code></p>
					<p>Get all top paths in an index:<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/toppaths</code></p>
					<p>Get disk space info for all top paths in an index:<br />
					<code>GET http://localhost:8000/api.php/diskover-2018.01.17/diskspace</code></p>
					<br>
					<h4>Update (with JSON object)</h4>
					<p>Updating file/directory tags is done with the PUT method. You can send a JSON object in the body. The call returns the status and number of items updated.<br />
					<p>Curl example:<br />
					<code>curl -X PUT http://localhost:8000/api.php/index/endpoint -d '{}'</code></p>
					<p>Tag files "delete":<br />
					<code>PUT http://localhost:8000/api.php/diskover-2018.01.17/tagfiles</code></p>
					<code>{"tags": ["delete"], "files": ["/Users/shirosai/file1.png", "/Users/shirosai/file2.png"]}</code></p>
                    <p>Tag files with tags "archive" and "version 1":<br />
					<code>PUT http://localhost:8000/api.php/diskover-2018.01.17/tagfiles</code></p>
					<code>{"tags": ["archive", "version 1"], "files": ["/Users/shirosai/file1.png", "/Users/shirosai/file2.png"]}</code></p>
					<p>Remove tag "delete" for files which are tagged "delete":<br />
					<code>PUT http://localhost:8000/api.php/diskover-2018.01.17/tagfiles</code></p>
					<code>{"tags": ["delete"], "files": ["/Users/shirosai/file1.png", "/Users/shirosai/file2.png"]}</code></p>
					<p>Remove all tags for files:<br />
					<code>PUT http://localhost:8000/api.php/diskover-2018.01.17/tagfiles</code></p>
					<code>{"tags": [], "files": ["/Users/shirosai/file1.png", "/Users/shirosai/file2.png"]}</code></p>
					<p>Tag directory "archive" (non-recursive):<br />
					<code>PUT http://localhost:8000/api.php/diskover-2018.01.17/tagdirs</code></p>
					<code>{"tags": ["archive"], "dirs": ["/Users/shirosai/Downloads"]}</code></p>
					<p>Tag directories and all files in directories with tags "archive" and "version 1" (non-recursive):<br />
					<code>PUT http://localhost:8000/api.php/diskover-2018.01.17/tagdirs</code></p>
					<code>{"tags": ["archive", "version 1"], "dirs": ["/Users/shirosai/Downloads", "/Users/shirosai/Documents"], "tagfiles": "true"}</code></p>
                    <p>Tag directory and all sub dirs (no files) with tag "version 1" (recursive):<br />
					<code>PUT http://localhost:8000/api.php/diskover-2018.01.17/tagdirs</code></p>
					<code>{"tags": ["version 1"], "dirs": ["/Users/shirosai/Downloads"], "recursive": "true"}</code></p>
                    <p>Tag directory and all items (files/directories) in directory and all sub dirs with tag "version 1" (recursive):<br />
					<code>PUT http://localhost:8000/api.php/diskover-2018.01.17/tagdirs</code></p>
					<code>{"tags": ["version 1"], "dirs": ["/Users/shirosai/Downloads"], "recursive": "true", "tagfiles": "true"}</code></p>
					<p>Remove tag "archive" from directory which is tagged "archive":<br />
					<code>PUT http://localhost:8000/api.php/diskover-2018.01.17/tagdirs</code></p>
					<code>{"tags": ["archive"], "dirs": ["/Users/shirosai/Downloads"]}</code></p>
                    <p>Remove all tags from directory and all files in directory (non-recursive):<br />
					<code>PUT http://localhost:8000/api.php/diskover-2018.01.17/tagdirs</code></p>
					<code>{"tags": [], "dirs": ["/Users/shirosai/Downloads"], "tagfiles": "true"}</code></p>
                    <p>Remove all tags from directory and all items (files/directories) in directory and all sub dirs (recursive):<br />
					<code>PUT http://localhost:8000/api.php/diskover-2018.01.17/tagdirs</code></p>
					<code>{"tags": [], "dirs": ["/Users/shirosai/Downloads"], "recursive": "true", "tagfiles": "true"}</code></p>
				</div>
			</div>
		</div>
		</div>

		<script language="javascript" src="js/jquery.min.js"></script>
		<script language="javascript" src="js/bootstrap.min.js"></script>
		<script language="javascript" src="js/diskover.js"></script>
</body>

</html>
