<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

ob_start();
require '../vendor/autoload.php';
require "../src/diskover/Auth.php";
require '../src/diskover/config_inc.php';

use diskover\ApiUserDatabase;

// Set logging level
error_reporting(E_ERROR | E_PARSE);

// license check
// DO NOT ALTER, REMOVE THIS CODE OR COMMENT IT OUT.
// REMOVING THE LICENSE CHECK VIOLATES THE LICENSE AGREEMENT AND IS AN ILLEGAL OFFENCE.
$lic->feature_check();
// end license check

$msg = '';
// If any POST hits this page, attempt to process.
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    session_start();

    $db = new ApiUserDatabase();
    $db->connect();
    $user = $db->findUser($config->API_USER);
    $initialPassword = false;
    if ($user->validatePassword($config->API_PASS)) {
        // Default password is valid
        $initialPassword = true;
    }
    $result = $db->changePassword($initialPassword);

    if ($result === '') {
        // Successful password change
        $msg = '<p class="text-success login-success"><i class="glyphicon glyphicon-ok-sign"></i> API password changed.</p>';
    } else {
        // Failed password change, inform user.
        $msg = '<p class="text-danger login-error"><i class="glyphicon glyphicon-ban-circle"></i> '.$result.'</p>';
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', 'G-NDFBQ1BYMH');
        </script>
    <?php } ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>diskover &mdash; API Password Change</title>
    <link rel="stylesheet" href="css/fontawesome-free/css/all.min.css" media="screen" />
    <link rel="stylesheet" href="css/bootswatch.min.css" media="screen" />
    <link rel="stylesheet" href="css/diskover.css" media="screen" />
    <link rel="icon" type="image/png" href="images/diskoverfavico.png" />
    <style>
        .login-logo {
            text-align: center;
            padding: 40px 0 0 0;
        }

        .login {
            width: 400px;
            background-color: #2F3338;
            box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
            margin: 100px auto;
        }

        .login h1 {
            text-align: center;
            color: #ffffff;
            font-size: 24px;
            padding: 0 0 5px 0;
        }

        .login h4 {
            text-align: center;
            color: #cccccc;
            font-size: 18px;
            padding: 0 10px 20px;
            border-bottom: 1px solid #000000;
        }

        .login-error {
            text-align: center;
            color: #ffcccc;
            font-size: 16px;
            margin-top: 20px;
            padding:0 20px;
        }

        .login-error.text-danger:hover {
            color: #ffcccc;
        }

        .login-success {
            text-align: center;
            font-size: 16px;
            margin-top: 20px;
            padding:0 20px;
        }

        .login form {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            padding-top: 20px;
        }

        .login form label {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 50px;
            height: 50px;
            background-color: #1C1E21;
            color: lightgray;
        }

        .login form input[type="password"] {
            width: 310px;
            height: 50px;
            border: 1px solid #000000;
            margin-bottom: 20px;
            padding: 0 15px;
            font-size: 16px;
        }

        .login form input[type="submit"] {
            width: 100%;
            padding: 15px;
            margin-top: 20px;
            border: 0;
            cursor: pointer;
            font-weight: bold;
            font-size: 16px;
            color: #ffffff !important;
            background-color: #3C4247 !important;
            transition: background-color 0.2s;
        }

        .login form input[type="submit"]:hover {
            background-color: #474D54 !important;
            transition: background-color 0.2s;
        }
    </style>
</head>

<body>
<div class="login">
  <div class="login-logo"><img src="images/diskover.png" alt="diskover" width="249" height="189" /></div>
  <h1>API Password Change</h1>
  <h4>
    <?php if ($initialPassword): ?>
      Please set your initial API password.
    <?php else: ?>
      Please enter your existing API password, and choose a new API password.
    <?php endif; ?>
  </h4>
  <?php echo $msg; ?>
  <form method="post">
    <?php if (!$initialPassword): ?>
      <label for="apipasswordCurrent">
        <i class="fas fa-lock"></i>
      </label>
      <input type="password" class="form-control" name="apipasswordCurrent" id="apipasswordCurrent" placeholder="Current Password" required>
    <?php endif; ?>

    <label for="apipassword">
      <i class="fas fa-lock"></i>
    </label>
    <input type="password" class="form-control" name="apipassword" id="apipassword" placeholder="New Password" required>

    <label for="apipassword2">
      <i class="fas fa-lock"></i>
    </label>
    <input type="password" class="form-control" name="apipassword2" id="apipassword2" placeholder="Retype New Password" required>
    <input type="submit" value="Save Password" onclick="loadingShow()">
  </form>
  <div id="loading">
    <img id="loading-image" width="32" height="32" src="images/ajax-loader.gif" alt="Loading..." />
    <div id="loading-text">Loading... please wait...</div>
  </div>
</div>
</body>

<script type="text/javascript">
    var errormsg = '<?php echo $msg ?>';
    if (errormsg) {
        loadingHide();
    }

    function loadingShow() {
        if (document.getElementById('password').value !== '' && document.getElementById('password2').value !== '') {
            document.getElementById('loading').style.display = 'block';
        }
    }

    function loadingHide() {
        document.getElementById('loading').style.display = 'none';
    }
</script>

</html>
