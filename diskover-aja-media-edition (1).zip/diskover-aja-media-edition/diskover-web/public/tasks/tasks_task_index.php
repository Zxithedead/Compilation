<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../../vendor/autoload.php';
require "../../src/diskover/Auth.php";
require "../../src/diskover/Diskover.php";
require "tasks_inc.php";


// check if form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nameErr = $pathsErr = $customindexnameErr = $altconfigErr = $retriesErr =
        $retrydelayErr = $scheduleMinErr = $scheduleHourErr = $scheduleDayOfMonthErr =
        $scheduleMonthErr = $scheduleDayOfWeekErr = $customScheduleErr = $templateNameErr = 
        $emailErr = $postCommandArgsErr = $timeoutErr = "";
    $id = $name = $desc = $paths = $altscanner = $altscanner_dircache = $clioptions = $autoindexname = 
        $customindexname = $overwriteindex = $usedefaultconfig = $altconfig = $schedulemin = $schedulehour = 
        $scheduledayofmonth = $schedulemonth = $scheduledayofweek = $customschedule = $envvars = $precommand =
        $precommandargs = $postcommand = $postcommandargs = $retries = $retrydelay =
        $assignedworker = $email = $maketemplate = $templatename = $disabled = 
        $timedout = "";

    // check if new task or editing
    $action = ($_POST['action'] === 'edit') ? 'edit' : null;

    // validate form

    $task_id = $_POST["task_id"];
    if (empty($_POST["name"])) {
        $nameErr = "* Name is required";
    } else {
        $name = test_input($_POST["name"]);
    }
    $desc = test_input($_POST["desc"]);
    if (empty($_POST["paths"])) {
        $pathsErr = "* Path is required";
    } elseif (preg_match('/\,/', $_POST["paths"])) {
        $pathsErr = "* Path is invalid";
    } else {
        $paths = "";
        $paths_arr = explode("\n", $_POST["paths"]);
        foreach ($paths_arr as $p) {
            // strip off any whitespace
            $p = trim($p);
            // strip off any trailing slashes
            $p = rtrim($p, '/\\');
            // replace any spaces in path to escaped space (Windows paths)
            $p = preg_replace('/\s/', '\\ ', $p);
            // escape all single backslash (Windows paths)
            $p = preg_replace('/\\\\{1}/', '\\\\\\', $p);
            // replace two or more backslash to escaped single backslash (Windows paths)
            $p = preg_replace('/\\\\{2,}/', '\\\\\\', $p);
            // replace two or more backslash and space to single backslash and space (Windows paths)
            $p = preg_replace('/\\\\{2,}\s/', '\\ ', $p);
            // escape UNC backslashes (Windows paths)
            if (strpos($p, '\\\\') === 0) {
                $p = preg_replace('/^\\\\/', '\\\\\\\\\\', $p, 1);
            }
            $paths .= $p . "\n";
        }
        $paths = trim($paths);
    }
    $altscanner = $_POST["altscanner"];
    $clioptions = $_POST["clioptions"];
    $autoindexname = ($_POST["autoindexname"] === "on") ? true : false;
    if (!$autoindexname && empty($_POST["customindexname"])) {
        $customindexnameErr = "* Custom index name is required";
    } elseif (!empty($_POST["customindexname"])) {
        $customindexname = test_input($_POST["customindexname"]);
        // check index name is valid
        if (
            substr($customindexname, 0, 9) !== 'diskover-' ||
            preg_match('/([A-G]|[I-L]|[N-R]|[T-X]|Z)/', $customindexname) ||
            preg_match('/(\\\|\\/|\*|\?|"|<|>|\|| |\,|\#)/', $customindexname) ||
            strlen($customindexname) > 255 ||
            strlen($customindexname) < 10
        ) {
            $customindexnameErr = "* Custom index name is invalid";
        }
    }
    $overwriteindex = ($_POST["overwriteindex"] === "on") ? true : false;
    $addtoindex = ($_POST["addtoindex"] === "on") ? true : false;
    if ($addtoindex && empty($_POST["customindexname"])) {
        $customindexnameErr = "* Custom index name is required when add to index selected";
    }
    $usedefaultconfig = ($_POST["usedefaultconfig"] === "on") ? true : false;
    if (!$usedefaultconfig && empty($_POST["altconfig"])) {
        $altconfigErr = "* Alternate config file directory path is required";
    } elseif (!empty($_POST["altconfig"])) {
        $altconfig = test_input($_POST["altconfig"]);
        $usedefaultconfig = false;
    }
    $schedulemin = $_POST["schedulemin"];
    if (empty($_POST["customschedule"]) && empty($schedulemin) && !is_numeric($schedulemin)) {
        $scheduleMinErr = "* Schedule minute is required";
    }
    $schedulehour = $_POST["schedulehour"];
    if (empty($_POST["customschedule"]) && empty($schedulehour) && !is_numeric($schedulehour)) {
        $scheduleHourErr = "* Schedule hour is required";
    }
    $scheduledayofmonth = $_POST["scheduledayofmonth"];
    if (empty($_POST["customschedule"]) && empty($scheduledayofmonth)) {
        $scheduleDayOfMonthErr = "* Schedule day of month is required";
    }
    $schedulemonth = $_POST["schedulemonth"];
    if (empty($_POST["customschedule"]) && empty($schedulemonth)) {
        $scheduleMonthErr = "* Schedule month is required";
    }
    $scheduledayofweek = $_POST["scheduledayofweek"];
    if (empty($_POST["customschedule"]) && empty($scheduledayofweek) && !is_numeric($scheduledayofweek)) {
        $scheduleDayOfWeekErr = "* Schedule day of week is required";
    }
    $customschedule = test_input($_POST["customschedule"]);
    if (!empty($_POST["customschedule"]) && 
        !preg_match('/^([1-5]?[0-9]|\*\/[1-5]?[0-9]|([1-5]?[0-9]((\,|\-)[1-5]?[0-9])*)+|\*) ((2[0-3]|1[0-9]|[0-9])|\*\/(2[0-3]|1[0-9]|[0-9])|([1-5]?[0-9]((\,|\-)[1-5]?[0-9])*)+|\*) ((3[01]|[12][0-9]|[1-9])|\*\/(3[01]|[12][0-9]|[1-9])|([1-5]?[0-9]((\,|\-)[1-5]?[0-9])*)+|\*) ((1[0-2]|[1-9])|\*\/(1[0-2]|[1-9])|([1-5]?[0-9]((\,|\-)[1-5]?[0-9])*)+|\*) ([0-6]|\*\/[0-6]|([1-5]?[0-9]((\,|\-)[1-5]?[0-9])*)+|\*)$/', $customschedule)
    ) {
        $customScheduleErr = "* Custom schedule is invalid";
    } elseif (!empty($_POST["customschedule"])) {
        // update scheduled time with custom schedule
        $customschedule_arr = explode(" ", $customschedule);
        $schedulemin = $customschedule_arr[0];
        $schedulehour = $customschedule_arr[1];
        $scheduledayofmonth = $customschedule_arr[2];
        $schedulemonth = $customschedule_arr[3];
        $scheduledayofweek = $customschedule_arr[4];
    }
    $envvars = $_POST["envvars"];
    $precommand = $_POST["precommand"];
    $precommandargs = $_POST["precommandargs"];
    $postcommand = $_POST["postcommand"];
    $postcommandargs = $_POST["postcommandargs"];
    if (preg_match('/\{indexname\}/', $postcommandargs) && empty($_POST["customindexname"])) {
        $postCommandArgsErr = "* Custom index name is required when using {indexname}";
    }
    if (!is_numeric($_POST["retries"])) {
        $retriesErr = "* Retries number required";
    } else {
        $retries = test_input($_POST["retries"]);
    }
    if (!is_numeric($_POST["retrydelay"])) {
        $retrydelayErr = "* Retry delay number is required";
    } else {
        $retrydelay = test_input($_POST["retrydelay"]);
    }
    if (!is_numeric($_POST["timeout"])) {
        $timeoutErr = "* Timeout number required";
    } else {
        $timeout = test_input($_POST["timeout"]);
    }
    $assignedworker = $_POST["assignedworker"];
    $email = test_input($_POST["email"]);
    if (!empty($_POST["email"])) {
        // check if e-mail address' are well-formed
        $email_list = explode(',', str_replace(' ', '', $email));
        foreach ($email_list as $emailaddr) {
            if (!filter_var($emailaddr, FILTER_VALIDATE_EMAIL)) {
                $emailErr = "* Invalid email format";
                break;
            }
        }
    }
    $maketemplate = ($_POST["maketemplate"] === "on") ? true : false;
    $templatename = test_input($_POST["templatename"]);
    if (!empty($_POST["maketemplate"]) && empty($templatename)) {
        $templateNameErr = "* Template name is required";
    }
    $disabled = ($_POST["disabled"] === "on") ? true : false;

    if (
        empty($nameErr) && empty($pathsErr) && empty($customindexnameErr) && empty($altconfigErr) &&
        empty($retriesErr) && empty($retrydelayErr) && empty($scheduleMinErr) && empty($scheduleHourErr) &&
        empty($scheduleDayOfMonthErr) && empty($scheduleMonthErr) && empty($scheduleDayOfWeekErr) &&
        empty($customScheduleErr) && empty($templateNameErr) && empty($emailErr) && empty($postCommandArgsErr) 
        && empty($timeoutErr)
    ) {
        // create new task array
        $newtask = [
            "id" => $task_id,
            "type" => "index",
            "name" => $name,
            "description" => $desc,
            "crawl_paths" => $paths,
            "alt_scanner" => $altscanner,
            "cli_options" => $clioptions,
            "auto_index_name" => $autoindexname,
            "custom_index_name" => $customindexname,
            "overwrite_existing" => $overwriteindex,
            "add_to_index" => $addtoindex,
            "use_default_config" => $usedefaultconfig,
            "alt_config_file" => $altconfig,
            "run_min" => $schedulemin,
            "run_hour" => $schedulehour,
            "run_day_month" => $scheduledayofmonth,
            "run_month" => $schedulemonth,
            "run_day_week" => $scheduledayofweek,
            "env_vars" => $envvars,
            "pre_command" => $precommand,
            "pre_command_args" => $precommandargs,
            "post_command" => $postcommand,
            "post_command_args" => $postcommandargs,
            "retries" => $retries,
            "retry_delay" => $retrydelay,
            "last_start_time" => null,
            "last_finish_time" => null,
            "last_success_finish_time" => null,
            "last_update_time" => null,
            "last_status" => null,
            "last_worker" => null,
            "assigned_worker" => $assignedworker,
            "email" => $email,
            "disabled" => $disabled,
            "timeout" => $timeout
        ];

        // read tasks json file
        $filename = 'tasks.json';
        $tasks_json = readTasksFile($filename);
        $tasks_arr = json_decode($tasks_json, true);
        $tasks = $tasks_arr['tasks'];

        if ($_POST['action'] === 'edit') {
            // update task in tasks.json
            $newtasks = ['tasks' => []];
            foreach ($tasks as $task) {
                if ($newtask['id'] === $task['id']) {
                    // preserve existing task data for task times, status, worker, etc
                    $newtask['last_start_time'] = $task['last_start_time'];
                    $newtask['last_finish_time'] = $task['last_finish_time'];
                    $newtask['last_success_finish_time'] = $task['last_success_finish_time'];
                    $newtask['last_update_time'] = $task['last_update_time'];
                    $newtask['last_status'] = $task['last_status'];
                    $newtask['last_worker'] = $task['last_worker'];
                    $newtasks['tasks'][] = $newtask;
                } else {
                    $newtasks['tasks'][] = $task;
                }
            }
        } else {
            // add task to tasks.json
            $newtasks = $tasks_arr;
            $newtasks['tasks'][] = $newtask;            
        }
        $newtasks_json = json_encode($newtasks, JSON_PRETTY_PRINT);
        writeToTasksFile($filename, $newtasks_json);

        // create new task template
        if ($maketemplate) {
            // generate unique id for template
            $template_id = md5(uniqid(rand(), true));
            $newtemplate = [
                "id" => $template_id,
                "type" => "index",
                "name" => $templatename,
                "description" => $desc,
                "crawl_paths" => $paths,
                "alt_scanner" => $altscanner,
                "cli_options" => $clioptions,
                "auto_index_name" => $autoindexname,
                "custom_index_name" => $customindexname,
                "overwrite_existing" => $overwriteindex,
                "add_to_index" => $addtoindex,
                "use_default_config" => $usedefaultconfig,
                "alt_config_file" => $altconfig,
                "run_min" => $schedulemin,
                "run_hour" => $schedulehour,
                "run_day_month" => $scheduledayofmonth,
                "run_month" => $schedulemonth,
                "run_day_week" => $scheduledayofweek,
                "env_vars" => $envvars,
                "pre_command" => $precommand,
                "pre_command_args" => $precommandargs,
                "post_command" => $postcommand,
                "post_command_args" => $postcommandargs,
                "retries" => $retries,
                "retry_delay" => $retrydelay,
                "assigned_worker" => $assignedworker,
                "email" => $email,
                "disabled" => $disabled,
                "timeout" => $timeout
            ];

            // read tasks template json file
            $filename = 'templates.json';
            
            // read tasks template json file
            $templates_json = readTasksFile($filename);
            $templates_arr = json_decode($templates_json, true);

            // add task to templates.json
            $newtemplates = $templates_arr;
            $newtemplates['templates'][] = $newtemplate;

            $newtemplates_json = json_encode($newtemplates, JSON_PRETTY_PRINT);
            writeToTasksFile($filename, $newtemplates_json);
        }

        // redirect to task list
        header('Location: index.php');
        exit;
    }
} elseif (isset($_GET['action']) && $_GET['action'] === 'edit') {
    // edit task
    $action = 'edit';

    // read tasks json file
    $tasks_json = readTasksFile("tasks.json");
    $tasks_arr = json_decode($tasks_json, true);
    $tasks = $tasks_arr['tasks'];

    // get all data for task matching id
    $task_id = $_GET['id'];
    foreach ($tasks as $task) {
        if ($task_id === $task['id']) {
            $name = $task['name'];
            $desc = $task['description'];
            $paths = $task['crawl_paths'];
            $altscanner = $task['alt_scanner'];
            $clioptions = $task['cli_options'];
            $autoindexname = $task['auto_index_name'];
            $customindexname = $task['custom_index_name'];
            $overwriteindex = $task['overwrite_existing'];
            $addtoindex = $task['add_to_index'];
            $usedefaultconfig = $task['use_default_config'];
            $altconfig = $task['alt_config_file'];
            $schedulemin = $task['run_min'];
            $schedulehour = $task['run_hour'];
            $scheduledayofmonth = $task['run_day_month'];
            $schedulemonth = $task['run_month'];
            $scheduledayofweek = $task['run_day_week'];
            $customschedule = $task['run_min'] . ' ' . $task['run_hour'] . ' ' . $task['run_day_month'] . ' ' . $task['run_month'] . ' ' . $task['run_day_week'];
            $envvars = $task['env_vars'];
            $precommand = $task['pre_command'];
            $precommandargs = $task['pre_command_args'];
            $postcommand = $task['post_command'];
            $postcommandargs = $task['post_command_args'];
            $retries = $task['retries'];
            $retrydelay = $task['retry_delay'];
            $assignedworker = $task['assigned_worker'];
            $email = $task['email'];
            $disabled = $task['disabled'];
            $timeout = $task['timeout'];
            break;
        }
    }
} else {
    // check if using template
    if (isset($_GET['template']) && !empty($_GET['template'])) {
        // read tasks template json file
        $templates_json = readTasksFile("templates.json");
        $templates_arr = json_decode($templates_json, true);
        $templates = $templates_arr['templates'];

        // get all data for task matching id
        $template_to_use = $_GET['template'];

        foreach ($templates as $template) {
            if ($template_to_use === $template['name']) {
                $name = $template['name'];
                $desc = $template['description'];
                $paths = $template['crawl_paths'];
                $altscanner = $template['alt_scanner'];
                $clioptions = $template['cli_options'];
                $autoindexname = $template['auto_index_name'];
                $customindexname = $template['custom_index_name'];
                $overwriteindex = $template['overwrite_existing'];
                $addtoindex = $template['add_to_index'];
                $usedefaultconfig = $template['use_default_config'];
                $altconfig = $template['alt_config_file'];
                $schedulemin = $template['run_min'];
                $schedulehour = $template['run_hour'];
                $scheduledayofmonth = $template['run_day_month'];
                $schedulemonth = $template['run_month'];
                $scheduledayofweek = $template['run_day_week'];
                $customschedule = $template['run_min'] . ' ' . $template['run_hour'] . ' ' . $template['run_day_month'] . ' ' . $template['run_month'] . ' ' . $template['run_day_week'];
                $envvars = $template['env_vars'];
                $precommand = $template['pre_command'];
                $precommandargs = $template['pre_command_args'];
                $postcommand = $template['post_command'];
                $postcommandargs = $template['post_command_args'];
                $retries = $template['retries'];
                $retrydelay = $template['retry_delay'];
                $assignedworker = $template['assigned_worker'];
                $email = $template['email'];
                $disabled = $template['disabled'];
                $timeout = $template['timeout'];
                break;
            }
        }
    }

    // generate unique id for task
    $task_id = md5(uniqid(rand(), true));
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// read tasks template json file
if (!isset($templates)) {
    $templates_json = readTasksFile("templates.json");
    $templates_arr = json_decode($templates_json, true);
    $templates = $templates_arr['templates'];
}

// read workers json file
$workers_json = readTasksFile("workers.json");
$workers_arr = json_decode($workers_json, true);
$workers = $workers_arr['workers'];
// get all worker pools
$worker_pools = array();
foreach ($workers as $worker) {
    foreach ($worker['worker_pools'] as $pool) {
        $worker_pools[] = $pool;
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-NDFBQ1BYMH');
    </script>
    <?php } ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $pagetitle = ($_GET['action'] === 'new') ? "Create New Index Task" : "Edit Index Task" ?>
    <title>diskover &mdash; <?php echo $pagetitle ?></title>
    <link rel="stylesheet" href="../css/fontawesome-free/css/all.min.css" media="screen" />
    <link rel="stylesheet" href="../css/bootswatch.min.css" media="screen" />
    <link rel="stylesheet" href="../css/diskover-tasks.css" media="screen" />
    <link rel="icon" type="image/png" href="../images/diskoverfavico.png" />
</head>

<body>
    <?php include "tasks_nav.php"; ?>

    <div class="container-fluid" id="mainwindow" style="margin-top:70px">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2">
                <h1 class="page-header"><?php echo $pagetitle ?></h1>
                <form class="form-horizontal">
                    <fieldset>
                        <legend>Use Template</legend>
                        <div class="form-group">
                            <label for="selectTemplate" class="col-lg-2 control-label">Template</label>
                            <div class="col-lg-4">
                                <select onchange="loadTemplate('index', this.value)" class="form-control" id="selectTemplate">
                                    <option>Select a template</option>
                                    <?php foreach ($templates as $template) {
                                        if ($template['type'] === 'index') {
                                            echo '<option value="' . $template['name'] . '">' . $template['name'] . '</option>';
                                        }
                                    } ?>
                                </select>
                            </div>
                        </div>
                    </fieldset>
                </form>
                <form class="form-horizontal" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <input type="hidden" name="form_submitted" value="1">
                    <input type="hidden" name="task_id" value="<?php echo $task_id ?>">
                    <input type="hidden" name="action" value="<?php echo $action ?>">
                    <fieldset>
                        <legend>Task details</legend>
                        <div class="form-group">
                            <label for="inputID" class="col-lg-2 control-label">ID</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="id" id="inputID" placeholder="ID" disabled="" value="<?php echo $task_id ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputName" class="col-lg-2 control-label">Name</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="name" id="inputName" placeholder="Name" value="<?php echo htmlspecialchars($name) ?>">
                                <span class="text-danger"><?php echo $nameErr; ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputDesc" class="col-lg-2 control-label">Description</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="desc" id="inputDesc" placeholder="Description" value="<?php echo htmlspecialchars($desc) ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="textAreaPaths" class="col-lg-2 control-label">Crawl Directory(s)</label>
                            <div class="col-lg-10">
                                <textarea class="form-control" rows="3" name="paths" id="textAreaPaths" placeholder="Path(s)"><?php echo $paths ?></textarea>
                                <span class="text-danger"><?php echo $pathsErr; ?></span>
                                <span class="help-block">Path(s) you want to index.
                                    <ul>
                                        <li>Separate paths with newline to have multiple paths in index.</li>
                                        <li>Paths need to be accessible on assigned worker.</li>
                                    </ul>
                                </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputAltScanner" class="col-lg-2 control-label">Alt Scanner</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="altscanner" id="inputAltScanner" placeholder="Scanner Name" value="<?php echo $altscanner ?>">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" id="inputAltScannerDircache" name="altscanner_dircache" onclick="setAltScanner()" <?php echo ($altscanner == 'scandir_dircache') ? 'checked=""' : '' ?>>
                                        <span class="help-block">Use DirCache alt scanner (scandir_dircache) to cache directory lists.</span>
                                    </label>
                                </div>
                                <span class="help-block">Optional alternate scanner to use.
                                    <ul>
                                        <li>Example: <i>scandir_s3</i> </li>
                                        <li>Alt scanner needs to be accessible on assigned worker.</li>
                                    </ul>
                                </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputCliOptions" class="col-lg-2 control-label">CLI Options/Flags</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="clioptions" id="inputCliOptions" placeholder="CLI Options/Flags" value="<?php echo htmlspecialchars($clioptions) ?>">
                                <span class="help-block">Optional additional diskover.py cli options/flags to use.
                                    <ul>
                                        <li>Example: <i>-v</i> </li>
                                        <li>Use <i>python3 diskover.py -h</i> for cli options.</li>
                                    </ul>
                                </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputAutoIndexName" class="col-lg-2 control-label">Auto Index Name</label>
                            <div class="col-lg-10">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" id="inputAutoIndexName" name="autoindexname" <?php echo ($_GET['action'] === 'new' || $autoindexname === true || $autoindexname === 'on') ? ' checked=""' : '' ?>>
                                        <span class="help-block">Automatically name index. Defaults to <i>diskover-{toppaths}-{datetime}</i>.</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputCustomIndexName" class="col-lg-2 control-label">Custom Index Name</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" onkeyup="updateCustomIndexPreview(this.value)" id="inputCustomIndexName" name="customindexname" placeholder="Index Name" value="<?php echo $customindexname ?>">
                                <span class="text-danger"><?php echo $customindexnameErr; ?></span><br>
                                <span class="text-info" id="customindexpreview"></span>
                                <span class="help-block">Custom index name. Overrides auto index name. To add date/time stamps use the below date vars.<br>
                                    For example, to add a datetime stamp like 2021-02-15_23_59_01 use %Y-%m-%d_%H_%M_%S<br>
                                    Date vars:
                                    <ul>
                                        <li>All date/times in UTC</li>
                                        <li>%Y for full year; %y for abbreviated year</li>
                                        <li>%m for month</li>
                                        <li>%d for day</li>
                                        <li>%H for hour</li>
                                        <li>%M for minute</li>
                                        <li>%S for second</li>
                                    </ul>
                                    Requirements:
                                    <ul>
                                        <li>Must start with <i>diskover-</i></li>
                                        <li>Lowercase only</li>
                                        <li>Cannot include \, /, *, ?, ", <,>, |, space (the character, not the word), ,, #</li>
                                        <li>Cannot be longer than 255 characters</li>
                                    </ul>
                                    Note:
                                    <ul>
                                        <li>If you are scanning frequently, more than every hour, don't forget to include the minute %M in the index name</li>
                                    </ul>
                                </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputOverwriteIndex" class="col-lg-2 control-label">Overwrite Existing</label>
                            <div class="col-lg-10">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" id="inputOverwriteIndex" name="overwriteindex" <?php echo ($_GET['action'] === 'new'  || $overwriteindex === true || $overwriteindex === 'on') ? ' checked=""' : '' ?>>
                                        <span class="help-block">Overwrite existing index with same name if it exists.</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputAddToIndex" class="col-lg-2 control-label">Add To Index</label>
                            <div class="col-lg-10">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" id="inputAddToIndex" name="addtoindex" <?php echo ($addtoindex === 'on') ? ' checked=""' : '' ?>>
                                        <span class="help-block">Add path(s) to existing index. Requires custom index name.</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputUseDefaultConfig" class="col-lg-2 control-label">Use Default Config</label>
                            <div class="col-lg-10">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" id="inputUseDefaultConfig" name="usedefaultconfig" <?php echo ($_GET['action'] === 'new'  || $usedefaultconfig === true || $usedefaultconfig === 'on') ? ' checked=""' : '' ?>>
                                        <span class="help-block">Use default diskover config file.</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputAltConfig" class="col-lg-2 control-label">Alternate Config Directory</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="inputAltConfig" name="altconfig" placeholder="Config directory" value="<?php echo htmlspecialchars($altconfig) ?>">
                                <span class="text-danger"><?php echo $altconfigErr; ?></span>
                                <span class="help-block">Directory containing alternate diskover config file (config.yaml). Overrides use default config. Path needs to be accessible on assigned worker.</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-2 control-label">Schedule</label>
                            <label for="selectScheduleMin" class="col-lg-2 control-label">Minute</label>
                            <div class="col-lg-2">
                                <select onchange="updateSchedulePreview()" class="form-control input-sm" id="selectScheduleMin" name="schedulemin">
                                    <option></option>
                                    <?php if (isset($schedulemin)) { ?>
                                    <option value="<?php echo $schedulemin ?>" selected><?php echo $schedulemin ?></option>
                                    <?php } ?>
                                    <option value="*" <?php echo ($schedulemin === '*') ? 'selected' : '' ?>>*</option>
                                    <?php foreach (range(0, 59) as $n) {
                                        $sel = ($schedulemin === "$n") ? " selected" : "";
                                        echo "<option value=" . $n . "" . $sel . ">" . $n . "</option>";
                                    }
                                    ?>
                                </select>
                                <span class="text-danger"><?php echo $scheduleMinErr; ?></span>
                            </div>
                            <label for="selectScheduleHour" class="col-lg-2 control-label">Hour</label>
                            <div class="col-lg-2">
                                <select onchange="updateSchedulePreview()" class="form-control input-sm" id="selectScheduleHour" name="schedulehour">
                                    <option></option>
                                    <?php if (isset($schedulehour)) { ?>
                                    <option value="<?php echo $schedulehour ?>" selected><?php echo $schedulehour ?></option>
                                    <?php } ?>
                                    <option value="*" <?php echo ($schedulehour === '*') ? 'selected' : '' ?>>*</option>
                                    <?php foreach (range(0, 23) as $n) {
                                        $sel = ($schedulehour === "$n") ? " selected" : "";
                                        echo "<option value=" . $n . "" . $sel . ">" . $n . "</option>";
                                    }
                                    ?>
                                </select>
                                <span class="text-danger"><?php echo $scheduleHourErr; ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-2 control-label"> </label>
                            <label for="selectScheduleDayofMonth" class="col-lg-2 control-label">Day of Month</label>
                            <div class="col-lg-2">
                                <select onchange="updateSchedulePreview()" class="form-control input-sm" id="selectScheduleDayofMonth" name="scheduledayofmonth">
                                    <option></option>
                                    <?php if (isset($scheduledayofmonth)) { ?>
                                    <option value="<?php echo $scheduledayofmonth ?>" selected><?php echo $scheduledayofmonth ?></option>
                                    <?php } ?>
                                    <option value="*" <?php echo ($scheduledayofmonth === '*') ? 'selected' : '' ?>>*</option>
                                    <?php foreach (range(1, 31) as $n) {
                                        $sel = ($scheduledayofmonth === "$n") ? " selected" : "";
                                        echo "<option value=" . $n . "" . $sel . ">" . $n . "</option>";
                                    }
                                    ?>
                                </select>
                                <span class="text-danger"><?php echo $scheduleDayOfMonthErr; ?></span>
                            </div>
                            <label for="selectScheduleMonth" class="col-lg-2 control-label">Month</label>
                            <div class="col-lg-2">
                                <select onchange="updateSchedulePreview()" class="form-control input-sm" id="selectScheduleMonth" name="schedulemonth">
                                    <option></option>
                                    <?php if (isset($schedulemonth)) { ?>
                                    <option value="<?php echo $schedulemonth ?>" selected><?php echo $schedulemonth ?></option>
                                    <?php } ?>
                                    <option value="*" <?php echo ($schedulemonth === '*') ? 'selected' : '' ?>>*</option>
                                    <?php foreach (range(1, 12) as $n) {
                                        $sel = ($schedulemonth === "$n") ? " selected" : "";
                                        echo "<option value=" . $n . "" . $sel . ">" . $n . "</option>";
                                    }
                                    ?>
                                </select>
                                <span class="text-danger"><?php echo $scheduleMonthErr; ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-2 control-label"> </label>
                            <label for="selectScheduleDayofWeek" class="col-lg-2 control-label">Day of Week <br><small>(0 is Sunday)</small></label>
                            <div class="col-lg-2">
                                <select onchange="updateSchedulePreview()" class="form-control input-sm" id="selectScheduleDayofWeek" name="scheduledayofweek">
                                    <option></option>
                                    <?php if (isset($scheduledayofweek)) { ?>
                                    <option value="<?php echo $scheduledayofweek ?>" selected><?php echo $scheduledayofweek ?></option>
                                    <?php } ?>
                                    <option value="*" <?php echo ($scheduledayofweek === '*') ? 'selected' : '' ?>>*</option>
                                    <?php foreach (range(0, 6) as $n) {
                                        $sel = ($scheduledayofweek === "$n") ? " selected" : "";
                                        echo "<option value=" . $n . "" . $sel . ">" . $n . "</option>";
                                    }
                                    ?>
                                </select>
                                <span class="text-danger"><?php echo $scheduleDayOfWeekErr; ?></span>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-2 control-label"> </label>
                            <div class="col-lg-8">
                                <span class="help-block">
                                <ul><li>For schedule, wildcard * is for any.</li>
                                    <li>All date/times are local timezone to the worker.</li>
                                    </ul>
                                Examples:
                                <ul>
                                    <li>run everyday at midnight: <span class="text-info">0 0 * * *</span></li>
                                    <li>run everyday at 10:01 pm: <span class="text-info">1 22 * * *</span></li>
                                    <li>run every Sunday at 7:30 am: <span class="text-info">30 7 * * 0</span></li>
                                    <li>run every hour: <span class="text-info">0 * * * *</span></li>
                                    <li>run every 5 min (custom): <span class="text-info">*/5 * * * *</span></li>
                                    <li>run every 2 hours (custom): <span class="text-info">0 */2 * * *</span></li>
                                    <li>run every hour from 7am to 11pm (custom): <span class="text-info">0 7-23 * * *</span></li>
                                </ul>
                                <pre>
┌───────────── minute (0 - 59)
│ ┌───────────── hour (0 - 23)
│ │ ┌───────────── day of the month (1 - 31)
│ │ │ ┌───────────── month (1 - 12)
│ │ │ │ ┌───────────── day of the week (0 - 6) (Sunday to Saturday)
│ │ │ │ │ 
│ │ │ │ │
│ │ │ │ │
* * * * *</pre>
<span class="text-info" id="schedulepreview"></span></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputCustomSchedule" class="col-lg-2 control-label">Custom Schedule</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="inputCustomSchedule" name="customschedule" placeholder="Custom schedule" value="<?php echo $customschedule ?>">
                                <span class="text-danger"><?php echo $customScheduleErr; ?></span>
                                <span class="help-block">Set custom schedule using <a href="https://en.wikipedia.org/wiki/Cron" target="_blank" style="font-weight:bold">cron syntax</a>, overrides schedule above.</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputEnvVars" class="col-lg-2 control-label">Environment Vars</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="inputEnvVars" name="envvars" placeholder="Environment vars" value="<?php echo htmlspecialchars($envvars) ?>">
                                <span class="help-block">Set environment vars before running commands. Separate multiple env vars with comma. Syntax VARNAME="value". </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputPreCommand" class="col-lg-2 control-label">Pre-Crawl Command</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="inputPreCommand" name="precommand" placeholder="Pre-Crawl Command" value="<?php echo htmlspecialchars($precommand) ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputPreCommandArgs" class="col-lg-2 control-label">Pre-Crawl Command Args</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="inputPreCommandArgs" name="precommandargs" placeholder="Pre-Crawl Command Args" value="<?php echo htmlspecialchars($precommandargs) ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputPostCommand" class="col-lg-2 control-label">Post-Crawl Command</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="inputPostCommand" name="postcommand" placeholder="Post-Crawl Command" value="<?php echo htmlspecialchars($postcommand) ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputPostCommandArgs" class="col-lg-2 control-label">Post-Crawl Command Args</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="inputPostCommandArgs" name="postcommandargs" placeholder="Post-Crawl Command Args" value="<?php echo htmlspecialchars($postcommandargs) ?>">
                                <span class="text-danger"><?php echo $postCommandArgsErr; ?></span>
                                <span class="help-block">Add <i>index name</i> using <i>{indexname}</i>. Requires custom index name.</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-10 col-lg-offset-2">
                                <span class="help-block"><i class="fas fa-info-circle"></i> For advanced commands that require shell redirection or meta characters run using bash or create a shell script. For Windows, run using cmd or powershell.<br>
                                <i class="fab fa-linux"></i> Linux examples:<br>
                                <pre>/bin/bash ./scripts/task-postcommands.sh</pre>
                                <pre>/bin/bash -c 'python3 /path/script.py > /path/script.log 2>&1'</pre><br>
                                <i class="fab fa-windows"></i> Windows examples:<br>
                                <pre>cmd.exe /c ".\scripts\task-postcommands-windows.bat"</pre><br>
                                <pre>powershell.exe "C:\path\script.ps1"</pre>
                                </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputRetries" class="col-lg-2 control-label">Retries</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="inputRetries" name="retries" placeholder="Retries" value="<?php echo (isset($retries)) ? $retries : 2 ?>">
                                <span class="text-danger"><?php echo $retriesErr; ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputRetryDelay" class="col-lg-2 control-label">Retry Delay (sec)</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="inputRetryDelay" name="retrydelay" placeholder="Retry Delay" value="<?php echo (isset($retrydelay)) ? $retrydelay : 60 ?>">
                                <span class="text-danger"><?php echo $retrydelayErr; ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputTimeout" class="col-lg-2 control-label">Timeout (sec)</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="inputTimeout" name="timeout" placeholder="Timeout" value="<?php echo (isset($timeout)) ? $timeout : 0 ?>">
                                <span class="text-danger"><?php echo $timeoutErr; ?></span>
                                <span class="help-block">Use 0 for no timeout (default).</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="selectWorker" class="col-lg-2 control-label">Assigned Worker</label>
                            <div class="col-lg-10">
                                <select class="form-control" id="selectWorker" name="assignedworker">
                                    <?php
                                    $sel = ($assignedworker === "any") ? " selected" : "";
                                    echo "<option" . $sel . ">any</option>";
                                    foreach ($workers as $worker) {
                                        $sel = ($assignedworker === $worker['name']) ? " selected" : "";
                                        echo "<option" . $sel . ">" . $worker['name'] . "</option>";
                                    }
                                    foreach ($worker_pools as $pool) {
                                        $sel = ($assignedworker === $pool) ? " selected" : "";
                                        echo "<option" . $sel . " value=\"". $pool."\">" . $pool . " (pool)</option>";
                                    } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputEmail" class="col-lg-2 control-label">Email</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="inputEmail" name="email" placeholder="Email" value="<?php echo $email ?>">
                                <span class="text-danger"><?php echo $emailErr; ?></span>
                                <span class="help-block">Send email when task finishes. Separate email addresses with comma. Requires task worker configured to send email.</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputDisabled" class="col-lg-2 control-label">Disabled</label>
                            <div class="col-lg-10">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" id="inputDisabled" name="disabled" <?php echo ($disabled === true || $disabled === 'on') ? ' checked=""' : '' ?>>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputMakeTemplate" class="col-lg-2 control-label">Make Template</label>
                            <div class="col-lg-10">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" id="inputMakeTemplate" name="maketemplate" <?php echo ($maketemplate === true || $maketemplate === 'on') ? ' checked=""' : '' ?>>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputMakeTemplateName" class="col-lg-2 control-label">Template Name</label>
                            <div class="col-lg-4">
                                <input type="text" class="form-control" id="inputMakeTemplateName" name="templatename" placeholder="Template Name" value="<?php echo $templatename ?>">
                                <span class="text-danger"><?php echo $templateNameErr; ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-10 col-lg-offset-2">
                                <button type="button" class="btn btn-default" onclick="window.location.href = 'index.php'">Cancel</button>
                                <?php $buttonlabel = ($action === 'edit') ? "Update Task" : "Create Task" ?>
                                <button type="submit" class="btn btn-primary"><?php echo $buttonlabel ?></button>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>

    <script language="javascript" src="../js/jquery.min.js"></script>
    <script language="javascript" src="../js/bootstrap.min.js"></script>
    <script language="javascript" src="../js/diskover.js"></script>
    <script>
        function setAltScanner() {
            if ($('#inputAltScanner').val() == 'scandir_dircache') {
                $('#inputAltScanner').val('');
            } else {
                $('#inputAltScanner').val('scandir_dircache');
            }
        }
    </script>
</body>

</html>