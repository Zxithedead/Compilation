<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';
require "../src/diskover/Diskover.php";

error_reporting(E_ALL ^ E_NOTICE);
set_time_limit(600);

$q = $_GET['q'];
$p = $_GET['p'];
$resultsize = $_GET['resultsize'];
$export = $_GET['export'];
$export_type = $_GET['export_type'];

$downloadurl = "export_download.php?q=$q&p=$p&resultsize=$resultsize&export=$export&export_type=$export_type";

echo "Downloading export file... please do not refresh the browser or close this window until the download completes.<br>";
echo "<a href=\"#\" onclick=\"window.close('','_parent','');\">Close window</a>";

// start the download in a hidden iframe
echo '<iframe name="downloadiframe" width="0" height="0" style="display:none" src="'.$downloadurl.'"></iframe>';
