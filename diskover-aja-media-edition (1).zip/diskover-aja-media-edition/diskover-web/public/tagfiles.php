<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';
require "../src/diskover/Diskover.php";


// check for post data from form
if (isset($_POST)) {
    // tag
    if ($_POST['tag']) {
        try {
            $searchParams = [];
            $searchParams['index'] = $_POST['docindex'];
            $searchParams['body'] = [
                'query' => [
                    'ids' => [
                        'type' => '_doc',
                        'values' => [ $_POST['id'] ]
                    ]
                ]
            ];
            $queryResponse = $client->search($searchParams);
        } catch (Exception $e) {
            handleError('ES error: ' . $e->getMessage(), false, true);
        }

        $docid = $queryResponse['hits']['hits'][0]['_id'];
        $docindex = $queryResponse['hits']['hits'][0]['_index'];
        $docindex_nocluster = $mnclient->getIndexNoCluster($docindex);
        $docsource = $queryResponse['hits']['hits'][0]['_source'];
        $doctype = $filesource['type'];

        // check if no tags
        if (!$docsource['tags']) {
            $docsource['tags'] = [];
        }
        // clear all tags
        if ($_POST['tag'] == "null") {
            $docsource['tags'] = NULL;
            // clear same tag
        } elseif (array_search($_POST['tag'], $docsource['tags']) !== false) {
            $tag_arr_dif = array_diff($docsource['tags'], array($_POST['tag']));
            $tag_arr = array_values($tag_arr_dif);
            if (count($docsource['tags']) == 0) {
                $docsource['tags'] = NULL;
            } else {
                $docsource['tags'] = $tag_arr;
            }
        } elseif ($_POST['tag'] === "tagall_subdirs_recurs") {
            runBckgrndProc("php tagfiles_process.php '".$docindex."' '".$docid."' 'directory' 'true'");
        } elseif ($_POST['tag'] === "tagall_files_recurs") {
            runBckgrndProc("php tagfiles_process.php '".$docindex."' '".$docid."' 'file' 'true'");
        } elseif ($_POST['tag'] === "tagall_all_recurs") {
            runBckgrndProc("php tagfiles_process.php '".$docindex."' '".$docid."' 'all' 'true'");
        } elseif ($_POST['tag'] === "tagall_subdirs_norecurs") {
            runBckgrndProc("php tagfiles_process.php '".$docindex."' '".$docid."' 'directory' 'false'");
        } elseif ($_POST['tag'] === "tagall_files_norecurs") {
            runBckgrndProc("php tagfiles_process.php '".$docindex."' '".$docid."' 'file' 'false'");
        } elseif ($_POST['tag'] === "tagall_all_norecurs") {
            runBckgrndProc("php tagfiles_process.php '".$docindex."' '".$docid."' 'all' 'false'");
            // add tag
        } else {
            $docsource['tags'][] = $_POST['tag'];
        }

        // update doc
        $params = [
            'refresh' => true,
            'id' => $docid,
            'index' => $docindex_nocluster,
            'body' => [
                'doc' => $docsource
            ]
        ];

        try {
            $updateclient = $mnclient->getClientByIndex($docindex_nocluster);
            $result = $updateclient->update($params);
        } catch (Exception $e) {
            handleError('ES error: ' . $e->getMessage(), false, true);
        }
    }
    // multi tag
    if ($_POST['multitag']) {
        // new tag
        if ($_POST['multitag_newtagtext']) {
            // save the text contents
            add_custom_tag($_POST['multitag_newtagtext']);
            $_POST['multitag'] = trim(explode('|', $_POST['multitag_newtagtext'])[0]);
        }
        // copy tag to all checked ids on page
        $checkedids = explode(",", $_POST['checkedids']);
        $checkedindices = explode(",", $_POST['checkedindices']);

        $n = sizeof($checkedids);
        $x = 1;
        foreach ($checkedids as $key => $val) {
            try {
                $searchParams = [];
                $searchParams['index'] = $checkedindices[$key];
                $searchParams['body'] = [
                    'query' => [
                        'ids' => [
                            'type' => '_doc',
                            'values' => [ $val ]
                        ]
                    ]
                ];
                $queryResponse = $client->search($searchParams);
            } catch (Exception $e) {
                handleError('ES error: ' . $e->getMessage(), false, true);
            }

            $docid = $queryResponse['hits']['hits'][0]['_id'];
            $docindex = $queryResponse['hits']['hits'][0]['_index'];
            $docindex_nocluster = $mnclient->getIndexNoCluster($docindex);
            $docsource = $queryResponse['hits']['hits'][0]['_source'];
            $doctype = $filesource['type'];

            if ($_POST['multitag'] === "tagall_subdirs_recurs") {
                runBckgrndProc("php tagfiles_process.php '".$docindex."' '".$docid."' 'directory' 'true'");
            } elseif ($_POST['multitag'] === "tagall_files_recurs") {
                runBckgrndProc("php tagfiles_process.php '".$docindex."' '".$docid."' 'file' 'true'");
            } elseif ($_POST['multitag'] === "tagall_all_recurs") {
                runBckgrndProc("php tagfiles_process.php '".$docindex."' '".$docid."' 'all' 'true'");
            } elseif ($_POST['multitag'] === "tagall_subdirs_norecurs") {
                runBckgrndProc("php tagfiles_process.php '".$docindex."' '".$docid."' 'directory' 'false'");
            } elseif ($_POST['multitag'] === "tagall_files_norecurs") {
                runBckgrndProc("php tagfiles_process.php '".$docindex."' '".$docid."' 'file' 'false'");
            } elseif ($_POST['multitag'] === "tagall_all_norecurs") {
                runBckgrndProc("php tagfiles_process.php '".$docindex."' '".$docid."' 'all' 'false'");
            } elseif ($_POST['multitag'] === "tagall_allresults") {
                //$tmpfile = makeTempFileQuery($q);
                runBckgrndProc("php tagfiles_process.php '".$docindex."' '".$docid."' 'all' 'true' '".$_POST['index']."' '".$_POST['q']."'");
            } else {
                // check if no tags
                if (!$docsource['tags']) {
                    $docsource['tags'] = [];
                }
                // clear all tags
                if ($_POST['multitag'] == "null") {
                    $docsource['tags'] = NULL;
                    // clear same tag
                } elseif (array_search($_POST['multitag'], $docsource['tags']) !== false) {
                    $tag_arr_dif = array_diff($docsource['tags'], array($_POST['multitag']));
                    $tag_arr = array_values($tag_arr_dif);
                    if (count($tag_arr) == 0) {
                        $docsource['tags'] = NULL;
                    } else {
                        $docsource['tags'] = $tag_arr;
                    }
                    // add tag
                } else {
                    $docsource['tags'][] = $_POST['multitag'];
                }

                // update doc
                $params = [
                    'id' => $docid,
                    'index' => $docindex_nocluster,
                    'body' => [
                        'doc' => $docsource
                    ]
                ];
                if ($x == $n) {
                    // refresh index so we see results right away when page reloads
                    $params['refresh'] = true;
                }

                try {
                    $updateclient = $mnclient->getClientByIndex($docindex_nocluster);
                    $result = $updateclient->update($params);
                } catch (Exception $e) {
                    handleError('ES error: ' . $e->getMessage(), false, true);
                }
            }
            $x++;
        }
    }
    // new tag
    if ($_POST['newtagtext']) {
        try {
            $searchParams = [];
            $searchParams['index'] = $_POST['docindex'];
            $searchParams['body'] = [
                'query' => [
                    'ids' => [
                        'type' => '_doc',
                        'values' => [ $_POST['id'] ]
                    ]
                ]
            ];
            $queryResponse = $client->search($searchParams);
        } catch (Exception $e) {
            handleError('ES error: ' . $e->getMessage(), false, true);
        }

        $docid = $queryResponse['hits']['hits'][0]['_id'];
        $docindex = $queryResponse['hits']['hits'][0]['_index'];
        $docindex_nocluster = $mnclient->getIndexNoCluster($docindex);
        $docsource = $queryResponse['hits']['hits'][0]['_source'];
        $doctype = $filesource['type'];

        // check if no tags
        if (!$docsource['tags']) {
            $docsource['tags'] = [];
        }
        // save the text contents
        add_custom_tag($_POST['newtagtext']);
        $newcustomtag = trim(explode('|', $_POST['tagtext'])[0]);
        $docsource['tags'][] = $newcustomtag;

        // update doc
        $params = [
            'refresh' => true,
            'id' => $docid,
            'index' => $docindex_nocluster,
            'body' => [
                'doc' => $docsource
            ]
        ];

        try {
            $updateclient = $mnclient->getClientByIndex($docindex_nocluster);
            $result = $updateclient->update($params);
        } catch (Exception $e) {
            handleError('ES error: ' . $e->getMessage(), false, true);
        }
    }
}


function makeTempFileQuery($q) {
    # make temporary file and store search query
    $tmpfname = tempnam(sys_get_temp_dir(), 'diskoverquery_');
    error_log('writing to temp file ' . $tmpfname);
    $handle = fopen($tmpfname, "w");
    fwrite($handle, $q);
    fclose($handle);
    return $tmpfname;
}