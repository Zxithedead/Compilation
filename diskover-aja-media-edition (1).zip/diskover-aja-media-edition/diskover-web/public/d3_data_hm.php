<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';
require "d3_inc.php";

// get indexname
$indexhm = $_GET['indexhm'];

// set client
$client = $mnclient->getClientByIndex($indexhm);

// check if path in session cache
if ($_SESSION["diskover_cache_heatmap"][$indexhm][$path] && $_GET['usecache'] == 1) {
    $data = $_SESSION["diskover_cache_heatmap"][$indexhm][$path];
} else {
    // get mtime in ES format
    $time = gettime($time);

    // create list to hold file/directory data from ES
    $data = [];

    // get dir total size and file count for index
    $dirinfo = get_dir_info($client, $indexhm, $path);

    // append index info to data list
    $data[] = [
        "name" => $path,
        "size" => $dirinfo[0],
        "count" => $dirinfo[1],
        "count_files" => $dirinfo[2],
        "count_subdirs" => $dirinfo[3],
        "modified" => $dirinfo[4],
        "type" => 'directory',
        "children" => walk_tree($client, $indexhm, $path, $filter, $time, $depth = 0, $maxdepth, $use_count, $show_files)
    ];

    // cache path data in session
    $_SESSION["diskover_cache_heatmap"][$indexhm][$path] = $data;
}

// output json encoded data for d3
echo json_encode($data);