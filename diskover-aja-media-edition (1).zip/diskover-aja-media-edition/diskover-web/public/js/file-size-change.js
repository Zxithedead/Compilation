/**
 * DataTable plugin for heatmap change size column.
 */

jQuery.fn.dataTable.ext.type.order['file-size-change-pre'] = function ( data ) {
    if (data === null || data === '') {
        return 0;
    }

    data = data.replace('<i style="color:#2AFE2F" class="fas fa-sort-down"></i> ','-');
    data = data.replace('<i style="color:#FF0001" class="fas fa-sort-up"></i> ', '');

    var matches = data.match( /^(\+?\-?\d+(?:\.\d+)?)\s*([a-z]+)/i );
    var multipliers = {
        b:  1,
        bytes: 1,
        kb: 1000,
        kib: 1024,
        mb: 1000000,
        mib: 1048576,
        gb: 1000000000,
        gib: 1073741824,
        tb: 1000000000000,
        tib: 1099511627776,
        pb: 1000000000000000,
        pib: 1125899906842624
    };

    if (matches) {
        var multiplier = multipliers[matches[2].toLowerCase()];
        return parseFloat( matches[1] ) * multiplier;
    } else {
        return -1;
    };
};
