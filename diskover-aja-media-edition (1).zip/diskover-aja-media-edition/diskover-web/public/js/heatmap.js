/*
diskover-web
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
 * d3 Heat map for diskover-web
 */

$(document).ready(function () {
    $('#changepath').click(function () {
        console.log('changing paths');
        var newpath = encodeURIComponent($('#pathinput').val());
        setCookie('path', newpath);
        location.href = "heatmap.php?index=" + index + "&index2=" + index2 + "&path=" + newpath + "&filter=" + filter + "&time=" + time + '&maxdepth=' + maxdepth + "&use_count=" + use_count + "&show_files=" + show_files + '&usecache=' + usecache;
        return false;
    });

    /* ------- SIZE/COUNT BUTTONS -------*/

    d3.select("#size").on("click", function () {
        use_count = 0;
        setCookie('use_count', 0);
        location.href = "heatmap.php?index=" + index + "&index2=" + index2 + "&path=" + encodeURIComponent(path) + "&filter=" + filter + "&time=" + time + '&maxdepth=' + maxdepth + "&use_count=" + use_count + "&show_files=" + show_files + '&usecache=' + usecache;
    });

    d3.select("#count").on("click", function () {
        use_count = 1;
        setCookie('use_count', 1);
        location.href = "heatmap.php?index=" + index + "&index2=" + index2 + "&path=" + encodeURIComponent(path) + "&filter=" + filter + "&time=" + time + '&maxdepth=' + maxdepth + "&use_count=" + use_count + "&show_files=" + show_files + '&usecache=' + usecache;
    });

    /* ------- SHOW FILES CHECKBOX -------*/

    d3.select("#showfiles").on("change", function () {
        var sf = document.getElementById('showfiles').checked;
        (sf) ? show_files = 1: show_files = 0;
        setCookie('show_files', show_files)
        usecache = 0;
        setCookie('usecache', 0);
        location.href = "heatmap.php?index=" + index + "&index2=" + index2 + "&path=" + encodeURIComponent(path) + "&filter=" + filter + "&time=" + time + '&maxdepth=' + maxdepth + "&use_count=" + use_count + "&show_files=" + show_files + '&usecache=' + usecache;
    });

    /* ------- MAXDEPTH BUTTONS -------*/

    d3.select("#depth1").on("click", function () {
        maxdepth = 1;
        setCookie('maxdepth', 1)
        usecache = 0;
        setCookie('usecache', 0);
        location.href = 'heatmap.php?index=' + index + '&index2=' + index2 + '&path=' + encodeURIComponent(path) + '&filter=' + filter + '&time=' + time + '&maxdepth=' + maxdepth + '&use_count=' + use_count + "&show_files=" + show_files + '&usecache=' + usecache;
    });
    d3.select("#depth2").on("click", function () {
        maxdepth = 2;
        setCookie('maxdepth', 2)
        usecache = 0;
        setCookie('usecache', 0);
        location.href = 'heatmap.php?index=' + index + '&index2=' + index2 + '&path=' + encodeURIComponent(path) + '&filter=' + filter + '&time=' + time + '&maxdepth=' + maxdepth + '&use_count=' + use_count + "&show_files=" + show_files + '&usecache=' + usecache;
    });
    d3.select("#depth3").on("click", function () {
        maxdepth = 3;
        setCookie('maxdepth', 3)
        usecache = 0;
        setCookie('usecache', 0);
        location.href = 'heatmap.php?index=' + index + '&index2=' + index2 + '&path=' + encodeURIComponent(path) + '&filter=' + filter + '&time=' + time + '&maxdepth=' + maxdepth + '&use_count=' + use_count + "&show_files=" + show_files + '&usecache=' + usecache;
    });
    d3.select("#depth4").on("click", function () {
        maxdepth = 4;
        setCookie('maxdepth', 4)
        usecache = 0;
        setCookie('usecache', 0);
        location.href = 'heatmap.php?index=' + index + '&index2=' + index2 + '&path=' + encodeURIComponent(path) + '&filter=' + filter + '&time=' + time + '&maxdepth=' + maxdepth + '&use_count=' + use_count + "&show_files=" + show_files + '&usecache=' + usecache;
    });
    d3.select("#depth5").on("click", function () {
        maxdepth = 5;
        setCookie('maxdepth', 5)
        usecache = 0;
        setCookie('usecache', 0);
        location.href = 'heatmap.php?index=' + index + '&index2=' + index2 + '&path=' + encodeURIComponent(path) + '&filter=' + filter + '&time=' + time + '&maxdepth=' + maxdepth + '&use_count=' + use_count + "&show_files=" + show_files + '&usecache=' + usecache;
    });

    d3.select("#depth" + maxdepth).classed("active", true);
    for (i = 1; i <= 5; i++) {
        if (i != maxdepth) {
            d3.select("#depth" + i).classed("active", false);
        }
    }

    /* ------- SHOW NEW DIRS CHECKBOX -------*/

    d3.select("#shownewdirs").on("change", function () {
        var snd = document.getElementById('shownewdirs').checked;
        (snd) ? show_new_dirs = 1: show_new_dirs = 0;
        setCookie('show_new_dirs', show_new_dirs);
        usecache = 0;
        setCookie('usecache', 0)
        location.href = "heatmap.php?index=" + index + "&index2=" + index2 + "&path=" + path + "&filter=" + filter + "&time=" + time + '&maxdepth=' + maxdepth + "&use_count=" + use_count + "&show_new_dirs=" + show_new_dirs + '&show_files=' + show_files + '&usecache=' + usecache;
    });

    d3.select("#minsizefilter").on("click", function () {
        setCookie('usecache', 0);
    });

    d3.select("#timefilter").on("click", function () {
        setCookie('usecache', 0);
    });

    // set cookies
    setCookie('path', encodeURIComponent(path));
    setCookie('filter', filter);
    setCookie('time', time);
    setCookie('hide_thresh', hide_thresh);
    setCookie('use_count', use_count);
    setCookie('show_files', show_files);

});

function showHidden(root) {
    // data is loaded so let's show hidden elements on the page
    // update path field
    document.getElementById('pathinput').value = root.name;
    // show path input
    document.getElementById('path-container').style.display = 'inline-block';
    // show chart buttons div
    document.getElementById('chart-buttons').style.display = 'inline-block';
    // show chart div
    document.getElementById('heatmap-wrapper').style.display = 'block';
    // show tabe div
    document.getElementById('hotdirs-table-wrapper').style.display = 'block';
}

function getJson() {

    // config references
    var chartConfig = {
        target: 'mainwindow',
        data_url1: 'd3_data_hm.php?indexhm=' + index + '&path=' + encodeURIComponent(path) + '&filter=' + filter + '&time=' + time + '&maxdepth=' + maxdepth + '&use_count=' + use_count + '&show_files=' + show_files + '&usecache=' + usecache,
        data_url2: 'd3_data_hm.php?indexhm=' + index2 + '&path=' + encodeURIComponent(path) + '&filter=' + filter + '&time=' + time + '&maxdepth=' + maxdepth + '&use_count=' + use_count + '&show_files=' + show_files + '&usecache=' + usecache
    };

    // loader settings
    var opts = {
        lines: 12, // The number of lines to draw
        length: 6, // The length of each line
        width: 3, // The line thickness
        radius: 7, // The radius of the inner circle
        color: '#EE3124', // #rgb or #rrggbb or array of colors
        speed: 1.9, // Rounds per second
        trail: 40, // Afterglow percentage
        className: 'spinner', // The CSS class to assign to the spinner
    };

    // loader settings
    var target = document.getElementById(chartConfig.target);

    // trigger loader
    var spinner = new Spinner(opts).spin(target);

    // load json data from Elasticsearch
    // use d3 queue to load json files simultaneously
    var q = d3.queue()
        .defer(d3.json, chartConfig.data_url1)
        .defer(d3.json, chartConfig.data_url2)
        .await(function (error, data1, data2) {
            // display error if data1 has error message
            if (error) {
                jsonError(error);
            } else if ((data1.count === 0 && data1.size === 0) || (data2.count === 0 && data2.size === 0)) {
                spinner.stop();
                console.warn('No docs found in Elasticsearch');
                document.getElementById('warning').style.display = 'block';
                return false;
            }
            // combine data1 and data2
            var data = data1.concat(data2);
            //console.log(data)
            // stop spin.js loader
            spinner.stop();
            renderTreeMap(data);
            renderTable();
        });
}

function renderTreeMap(data) {

    svg.selectAll('.celllabel').remove();

    var data_index = data[0],
        data_index2 = data[1];

    var treemap = d3.layout.treemap()
        .round(false)
        .size([w, h])
        .sticky(false)
        .value(function (d) {
            var val = (use_count) ? d.count : d.size;
            return val;
        });

    node = root = data_index;
    node2 = root2 = data_index2;

    // show hidden elements on page
    showHidden(root);

    var nodes = treemap.nodes(root)
        .filter(function (d) {
            return !d.children;
        });

    var nodes2 = treemap.nodes(root2)
        .filter(function (d) {
            return !d.children;
        });

    // add index2 data (value) to nodes as value2 and add change_percent
    nodes.forEach(function (d) {
        var result = nodes2.filter(function (a) {
            return a.name === d.name;
        });
        d.value2 = (result[0] !== undefined) ? result[0].value : 0;
        if (d.value2 !== 0 && d.value !== 0) {
            d.change_percent = changePercent(d.value, d.value2);
        } else if (d.value2 === 0 && d.value === 0) {
            d.change_percent = 0;
        } else {
            d.change_percent = 100;
        }

        // add to hotdirsdata
        if (d.change_percent !== 0) {
            if (d.change_percent === 100 & show_new_dirs === 0) {
                return;
            }
            var change_icon = (d.change_percent > 0) ? '<i style="color:#FF0001" class="fas fa-sort-up"></i>' : '<i style="color:#2AFE2F" class="fas fa-sort-down"></i>';
            if (d.value2 > d.value) {
                var change_val = (use_count) ? numberWithCommas(d.value2 - d.value) : format(d.value2 - d.value);
            } else {
                var change_val = (use_count) ? numberWithCommas(d.value - d.value2) : format(d.value - d.value2);
            }
            hotdirsdata.push([
                basename(d.name),
                d.type[0].toUpperCase() + d.type.substring(1),
                (d.change_percent>0) ? change_icon + ' ' + '+' + change_val : change_icon + ' ' + change_val,
                (d.change_percent>0) ? change_icon + ' ' + '+' + d.change_percent.toFixed(2) + ' %' : change_icon + ' ' + d.change_percent.toFixed(2) + ' %',
                format(d.size),
                (result[0] !== undefined) ? format(result[0].size) : 0,
                (d.type === 'directory') ? numberWithCommas(d.count_files) : '', 
                (result[0] !== undefined && result[0].type === 'directory') ? numberWithCommas(result[0].count_files) : '0',
                (d.type === 'directory') ? numberWithCommas(d.count_subdirs) : '',
                (result[0] !== undefined && result[0].type === 'directory') ? numberWithCommas(result[0].count_subdirs) : '0',
                d.modified,
                dirname(d.name),
                '<a title="show path in heatmap" href="heatmap.php?index='+index+'&index2='+index2+'&path='+encodeURIComponent(dirname(d.name))+'&filter='+filter+'&time='+time+'&maxdepth='+maxdepth+'&use_count='+use_count+'&show_files='+show_files+'" target="_blank"><i class="fas fa-fire-alt"></i></a>&nbsp;&nbsp;<a title="search for path" href="search.php?index='+index+'&index2='+index2+'&submitted=true&p=1&q=parent_path:'+encodeURIComponent(escapeHTML(dirname(d.name)))+'&path='+encodeURIComponent(dirname(d.name))+'" target="_blank"><i class="fas fa-search"></i></a>'
            ]);
        }
    });
    //console.log(nodes)
    //console.log(hotdirsdata)

    // add node data to heatmap data list
    // add change percents to hotdirs list for table view
    nodes.forEach(function (d) {
        var x = d.x + (d.dx / 2);
        var y = d.y + (d.dy / 2);
        if (d.change_percent !== 0) {
            if (d.change_percent === 100 & show_new_dirs === 0) {
                return;
            }
            heatmapdata.push([x, y, d.change_percent]);
        }
    });
    //console.log(heatmapdata)

    var cell = svg.selectAll("g").data(nodes);

    min = d3.min(nodes, function (d) {
        return d.change_percent;
    });
    max = d3.max(nodes, function (d) {
        return d.change_percent;
    });

    // draw heatmap
    draw();

    var color = d3.scale.linear()
        .domain([min, 0, max])
        .range(["#29FE2F", "#181921", "#FD0D1B"]);

    cell.enter().append("g")
        .attr("class", "cell")
        .attr("transform", function (d) {
            return "translate(" + d.x + "," + d.y + ")";
        })
        .on("click", function (d) {
            location.href = 'heatmap.php?index=' + index + '&index2=' + index2 + '&path=' + encodeURIComponent(d.parent.name) + '&filter=' + filter + '&time=' + time + '&maxdepth=' + maxdepth + '&use_count=' + use_count + '&show_files=' + show_files + '&usecache=' + usecache
        })
        .on("mouseover", function (d) {
            tip.show(d);
        })
        .on("mouseout", function (d) {
            tip.hide(d);
        })
        .on('mousemove', function () {
            if (d3.event.pageY > window.innerHeight - 50) {
                // change tip for bottom of screen
                return tip
                    .style("top", (d3.event.pageY - 40) + "px")
                    .style("left", (d3.event.pageX + 10) + "px");
            } else if (d3.event.pageX > window.innerWidth - 200) {
                // change tip for right side of screen
                return tip
                    .style("top", (d3.event.pageY + 10) + "px")
                    .style("left", (d3.event.pageX - 200) + "px");
            } else {
                return tip
                    .style("top", (d3.event.pageY - 10) + "px")
                    .style("left", (d3.event.pageX + 10) + "px");
            }
        })
        .append("rect")
        .attr("left", function (d) {
            return d.dx + "px";
        })
        .attr("top", function (d) {
            return d.dy + "px";
        })
        .attr("width", function (d) {
            return Math.max(0, d.dx - 1) + "px";
        })
        .attr("height", function (d) {
            return Math.max(0, d.dy - 1) + "px";
        })
        .style("fill", function (d) {
            if (d.change_percent === 100 & show_new_dirs === 0) {
                return color(0);
            }
            return color(d.change_percent);
        })
        .attr("rx", 4);

    cell
        .style("fill", function (d) {
            return color(d.change_percent);
        })
        .append("text")
        .attr("x", function (d) {
            return d.dx / 2;
        })
        .attr("y", function (d) {
            return d.dy / 2;
        })
        .attr("dy", ".35em")
        .attr("text-anchor", "middle")
        .attr("class", "celllabel")
        .text(function (d) {
            return d.name.split('/').pop();
        })
        .style("opacity", function (d) {
            d.w = this.getComputedTextLength();
            return d.dx > d.w ? 1 : 0;
        });

    cell.exit()
        .remove();

    /* ------- TOOLTIP -------*/

    var tip = d3.tip()
        .attr('class', 'd3-tip')
        .html(function (d) {

            var rootval = (use_count) ? (node || root).count : (node || root).size;
            var rootval2 = (use_count) ? (node2 || root2).count : (node2 || root2).size;
            var percent = (d.value / rootval * 100).toFixed(1) + '%';
            var percent2 = (d.value2 / rootval2 * 100).toFixed(1) + '%';
            var sum = (use_count) ? d.value : format(d.value);
            var sum2 = (use_count) ? d.value2 : format(d.value2);
            var change_percent = d3.round(d.change_percent, 2);
            if (d.value2 > d.value) {
                var change_val = (use_count) ? numberWithCommas(d.value2 - d.value) : format(d.value2 - d.value);
            } else {
                var change_val = (use_count) ? numberWithCommas(d.value - d.value2) : format(d.value - d.value2);
            }
            var color = "white";
            var increase_decrease = "";
            if (change_percent > 0) {
                increase_decrease = '<i class="glyphicon glyphicon-chevron-up"></i> +';
                color = "#FD0D1B";
            } else if (change_percent < 0) {
                increase_decrease = '<i class="glyphicon glyphicon-chevron-down"></i>';
                color = "#29FE2F";
            }

            return "<span style='font-size:12px;color:white;'>" + d.name + "</span><br>current: <span style='color:#FD0D1B;'>" + sum + " (" + percent + ")</span><br>previous: <span style='color:white;'>" + sum2 + " (" + percent2 + ")</span><br></span>change: <span style='color:" + color + ";'>" + increase_decrease + change_val + ' (' + increase_decrease + change_percent + "%)</span></span>";
        });

    svg.call(tip);

    d3.select("#heatmap-container").append("div")
        .attr("class", "tooltip")
        .style("opacity", 0);
}


function renderTable() {
    // make data table
    $("#hotdirs-table").DataTable({
        "data": hotdirsdata,
        "stateSave": true,
        "lengthMenu": [10, 25, 50, 75, 100],
        "pageLength": 25,
        "columnDefs": [
            { 
                "type": "file-size", 
                targets: [4,5]
            },
            { 
                "type": "file-size-change", 
                targets: [2]
            },
            {
                "orderable": false,
                targets: [12]
            }
        ]
    });
}


var index = getCookie('index');
var index2 = getCookie('index2');

// display message if no index2 selected
if (index2 === "") {
    document.getElementById('index2req').style.display = 'block';
} else {
    // add filtersto statustext
    var status_filter = 'min size: ' + format(filter) + ', ';
    var status_time = ' time:' + time;
    document.getElementById('statusfilters').append(status_filter);
    document.getElementById('statusfilters').append(status_time);
    document.getElementById('statushidethresh').innerHTML = hide_thresh;

    var root,
        node,
        min,
        max;

    (use_count === '' || use_count === 0) ? use_count = 0 : use_count = 1;
    (use_count === 1) ? $('#count').addClass('active') : $('#size').addClass('active');

    (show_files === '' || show_files === 1) ? show_files = 1 : show_files = 0;
    (show_files === 1) ? $('#showfiles').prop('checked', true) : $('#showfiles').prop('checked', false);

    var show_new_dirs = ($_GET('show_new_dirs')) ? parseInt($_GET('show_new_dirs')) : parseInt(getCookie('show_new_dirs'));
    (show_new_dirs === '' || show_new_dirs === 1) ? show_new_dirs = 1: show_new_dirs = 0;
    (show_new_dirs === 1) ? $('#shownewdirs').prop('checked', true): $('#shownewdirs').prop('checked', false);

    console.log("PATH:" + path);
    console.log("SIZE_FILTER:" + filter);
    console.log("TIME_FILTER:" + time);
    console.log("TIME_FIELD:" + timefield);
    console.log("MAXDEPTH:" + maxdepth);
    console.log("USECOUNT:" + use_count);
    console.log("SHOWNEWDIRS:" + show_new_dirs);
    console.log("SHOWFILES:" + show_files);
    console.log("SIZE_FIELD:" + sizefield);

    console.time('loadtime')

    // d3 treemap
    var w = window.innerWidth - 40,
        h = window.innerHeight / 2.5,
        x = d3.scale.linear().range([0, w]),
        y = d3.scale.linear().range([0, h]);

    var svg = d3.select("#heatmap-container")
        .append("svg")
        .attr("class", "chart")
        .style("width", w + "px")
        .style("height", h + "px")
        .attr("width", w)
        .attr("height", h)
        .append("g")
        .attr("transform", "translate(.5,.5)");


    // heatmap

    window.requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame ||
        window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;

    function get(id) {
        return document.getElementById(id);
    }

    get('heatmap-overlay').width = w;
    get('heatmap-overlay').height = h;

    var heatmapdata = [];
    var hotdirsdata = [];

    var heat = simpleheat('heatmap-overlay'),
        frame;

    function draw() {
        var radius = 25,
            blur = 15,
            maxs = max;
            //maxs = (max > min * -1) ? max : min;

        console.time('draw');
        heat.clear();
        heat.data(heatmapdata);
        heat.max(maxs);
        console.log('HEATMAP_MAX:' + maxs)
        heat.radius(radius, blur);
        console.log('HEATMAP_RADIUS:' + radius)
        console.log('HEATMAP_BLUR:' + blur)
        heat.draw();
        console.timeEnd('draw');
        frame = null;
    }

    // get data from Elasticsearh 
    getJson();

    console.timeEnd('loadtime');
}