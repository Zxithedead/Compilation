<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
example file action to list local or remote directory over ssh
*/


// override debug output in fileactions include file
//$fileactions_debug = FALSE;

include 'includes/fileactions.php';
include 'includes/fileactions_header.php';


// in this example we are listing all selected items on search results page
// you can set fileactions_debug to TRUE above for debug info to print out fileinfo array

// use ssh to get remote directory
$use_ssh = false;
// ssh user and host
$ssh_host = "user@hostname";
$ssh_port = 22;
$ssh_verbose = false;
// path to ssh identity key file
$ssh_identity_file = "../../src/diskover/ssh_key.pem";


foreach ($fileinfo as $file) {
    $fullpath = $file['fullpath'];
    // uncomment below and set to translate paths
    //$path_translations = array(
    //    '/^\//' => '/mnt/'
    //);
    //$fullpath = translate_path($fullpath, $path_translations);

    // run command to get directory list of fullpath

    // check if Windows
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // top path to drive letter mapppings
        $translate_win = array(
            '/mnt/path1' => 'E:',
            '/mnt/path2' => 'F:'
        );
        $cmd = 'DATE.EXE & DIR "' . linux_to_windows($fullpath, $translate_win) . '"';
    } else {
        // Linux or MacOS
        // escape string for shell arg
        $fullpath = escapeshellarg($fullpath);
        $cmd = 'date && ls -la ' . $fullpath . ' 2>&1';
        // find alternative
        //$cmd = 'date && find ' . $fullpath . ' -maxdepth 1 | sort 2>&1';
    }

    // use ssh to get remote directory
    if ($use_ssh) {
        $verbose = ($ssh_verbose) ? "-v" : "";
        $cmd = 'ssh -x "-o StrictHostKeyChecking=no" ' . $verbose .' -p '.$ssh_port.' -i '.$ssh_identity_file.' '.$ssh_host.' "' . $cmd . '"';
    }

    // run exec and get output and return value
    $output = $retval = null;
    exec($cmd, $output, $retval);

    // print html output
    echo '
    <div class="container-fluid cmd-output">
    Command: ' . $cmd . '<br>
    Status:<br>
    <pre>' . $retval .'</pre>
    Output:<br>
    <pre>' . implode("\n", $output) . '</pre>
    </div>
    ';
}


include 'includes/fileactions_footer.php';