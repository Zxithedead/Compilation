<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
example file action to fix file permissions local or remote over ssh
*/


// override debug output in fileactions include file
$fileactions_debug = FALSE;

include 'includes/fileactions.php';
include 'includes/fileactions_header.php';


// in this example we are running chmod and snacl on all selected items on search results page
// you can set fileactions_debug to TRUE above for debug info to print out fileinfo array

// use ssh to get remote directory
$use_ssh = false;
// ssh user and host
$ssh_host = "user@hostname";
$ssh_port = 22;
$ssh_verbose = false;
// path to ssh identity key file
$ssh_identity_file = "../../src/diskover/ssh_key.pem";


function isApprovedPath($path) {
    /*
	Ensure a path is approved to have its permission changed
	Returns array(approved:bool, reason:str)
	*/
	
	# ==============
	# Global rejects
	# ==============

    $path_split = explode('/', $path);

    # Reject invalid paths
	if (!file_exists($path)) {
        return array(false, "Path not found");
    }

	# Reject if path is mount point of file system
    # e.g. /Volumes/titan, /Volumes/falcon
	if (count($path_split) < 4) {
        return array(false, "File system mount point folder");
    }

    # Reject if path is top 1st level directory
    # e.g. /Volumes/falcon/DMC, /Volumes/falcon/HA
	if (count($path_split) < 5) {
        return array(false, "Top 1st level folder");
    }
    
    # Reject if path contains Superlock (SL) folder
	if (array_search("SL", $path_split) !== false) {
        return array(false, "SuperLock folder");
    }

    # Reject if path contains Adhoc_clients folder
	if (array_search("Adhoc_clients", $path_split) !== false) {
        return array(false, "Adhoc clients folder");
    }

	# ===================
	# Group-based rejects
	# ===================

    # Get all ldap groups
	$grouplist = array();
    foreach ($_SESSION['ldapgroups'] as $grp) {
        $grouplist[] = strtolower($grp);
    }

	# TG Operators
	if (array_search("tg-artists", $grouplist) !== false) {
        if (preg_match("/^\/Volumes\/huron\/Title_Graphics\/(Incoming|Projects)\//", $path)) {
            return array(true, "Path is approved");
        }
    }
	
	# QC Operators
    if (array_search("dmc-qc", $grouplist) !== false) {
		# Only /Volumes/vol/HA/TITLE/* is approved
        if (array_search("HA", $path_split) == false || count($path_split) < 6) {
            return array(false, "Path not in HA/PROJECT/");
        } elseif (array_search("MILLER", $path_split) !== false) {
			return array(false, "This is a restricted project");
        } else {
            return array(true, "Path is approved");
        }
    }
	
	# Non-QC Operators can do HA or NHA
    elseif (array_search("dmc-ops", $grouplist) !== false || array_search("administrators", $grouplist) !== false) {
		if (array_search("HA", $path_split) !== false) {
			if (count($path_split) < 6) {
                return array(false, "Path not inside HA/PROJECT/");
            } elseif (array_search("MILLER", $path_split) !== false) {
				return array(false, "This is a restricted project");
            } else {
				return array(true, "Path is approved");
            }
        }

		# Only /Volumes/vol/HA/TITLE/* is approved
		if (array_search("NHA", $path_split) !== false) {
			if (count($path_split) < 5) {
				return array(false, "Path not inside NHA");
            } else {
				return array(true, "Path is approved");
            }
        }
		
		return array(false, "Path not in HA or NHA");
	
    } else {
        return array(false, "No applicable user group");   
    }
}


if (empty($_POST)) {
    $approved = array();
    $rejected = array();
    foreach ($fileinfo as $file) {
        $fullpath = $file['fullpath'];
        list($is_approved, $reason) = isApprovedPath($fullpath);
        if ($is_approved) {
            $approved[] = array($fullpath, $reason);
        } else {
            $rejected[] = array($fullpath, $reason);
        }
    }
    // Show form to confirm from user
    echo '<div class="container">
    <div class="well">
    <form class="form-horizontal" name="confirmform" method="post" action="'.htmlspecialchars($_SERVER["PHP_SELF"]).'">
    <input type="hidden" name="submit" value="true">
    <center style="background-color: #04115f"><img src="mickey_chmod.gif" alt="Mickey"></center>
    ';
    if (sizeof($approved) > 0) {
    echo '
    <p><strong>Are you sure you want to modify permissions for:</strong></p>
    <pre style="max-height: 200px; overflow: auto;">';
    foreach ($approved as $file) {
        echo $file[0] . "\n";
    }
    echo '</pre><hr/>';
    }
    if (sizeof($rejected) > 0) {
    echo '
    <p><strong>The following paths cannot be modified:</strong></p>
    <pre style="max-height: 200px; overflow: auto;">';
    foreach ($rejected as $file) {
        echo "<span style=\"color: #ff6347;\">" . $file[1] . ":</span>\t" . $file[0] .  "<br/>\n";
    }
    echo '</pre><hr/>';
    }
    echo '
    <div style="text-align: right;">';
    if (sizeof($approved) > 0) {
    echo '
    <button type="submit" class="btn btn-primary">Yes</button>
    <button type="button" class="btn btn-default" onClick="javascript:window.close(\'\',\'_parent\',\'\');">Cancel</button>
    ';
    } else {
    echo '
    <button type="button" class="btn btn-default" onClick="javascript:window.close(\'\',\'_parent\',\'\');">Close</button>
    ';
    }
    echo '
    </div>
    </form>
    </div>
    </div>';
} else {
    // form submitted, run fix file permission commands
    $succcess = array();
    $failed = array();

    foreach ($fileinfo as $file) {
        $fullpath = $file['fullpath'];
        // uncomment below and set to translate paths
        //$path_translations = array(
        //    '/^\//' => '/mnt/'
        //);
        //$fullpath = translate_path($fullpath, $path_translations);

        // escape string for shell arg
        $fullpath_esc = escapeshellarg($fullpath);

        // run chmod command on fullpath
        $cmd = 'chmod -Rf 777 ' . $fullpath_esc . ' 2>&1';

        // use ssh to get remote directory
        if ($use_ssh) {
            $verbose = ($ssh_verbose) ? "-v" : "";
            $cmd = 'ssh -x "-o StrictHostKeyChecking=no" ' . $verbose .' -p '.$ssh_port.' -i '.$ssh_identity_file.' '.$ssh_host.' "' . $cmd . '"';
        }

        // run exec and get output and return value
        $output = $retval = null;
        exec($cmd, $output, $retval);

        // print html output
        echo '
        <div class="container-fluid cmd-output">
        Command: ' . $cmd . '<br>
        Status:<br>
        <pre>' . $retval .'</pre>
        Output:<br>
        <pre>' . implode("\n", $output) . '</pre>
        </div>
        ';

        // run chgrp command on fullpath
        $cmd2 = 'chgrp -R ppse-bldg78-group ' . $fullpath_esc . ' 2>&1';

        // use ssh to get remote directory
        if ($use_ssh) {
            $verbose = ($ssh_verbose) ? "-v" : "";
            $cmd2 = 'ssh -x "-o StrictHostKeyChecking=no" ' . $verbose .' -p '.$ssh_port.' -i '.$ssh_identity_file.' '.$ssh_host.' "' . $cmd2 . '"';
        }

        // run exec and get output and return value
        $output2 = $retval2 = null;
        exec($cmd2, $output2, $retval2);

        // print html output
        echo '
        <div class="container-fluid cmd-output">
        Command: ' . $cmd2 . '<br>
        Status:<br>
        <pre>' . $retval2 .'</pre>
        Output:<br>
        <pre>' . implode("\n", $output2) . '</pre>
        </div>
        ';

        // run snacl command on fullpath
        $cmd3 = '/usr/cvfs/bin/snacl -RN ' . $fullpath_esc . ' 2>&1';

        // use ssh to get remote directory
        if ($use_ssh) {
            $verbose = ($ssh_verbose) ? "-v" : "";
            $cmd3 = 'ssh -x "-o StrictHostKeyChecking=no" ' . $verbose .' -p '.$ssh_port.' -i '.$ssh_identity_file.' '.$ssh_host.' "' . $cmd3 . '"';
        }

        // run exec and get output and return value
        $output3 = $retval3 = null;
        exec($cmd3, $output3, $retval3);

        // print html output
        echo '
        <div class="container-fluid cmd-output">
        Command: ' . $cmd3 . '<br>
        Status:<br>
        <pre>' . $retval3 .'</pre>
        Output:<br>
        <pre>' . implode("\n", $output3) . '</pre>
        </div>
        ';

        // check return value and add path to failed or success arrays
        if ($retval !== 0 || $retval2 !== 0 || $retval3 !== 0) {
            $failed[] = $fullpath;
        } else {
            $success[] = $fullpath;
        }
    }

    // print html summary
    if (!empty($success) && empty($failed)) {
        $summary_outcome = "All permissions have been repaired.";
    } elseif (!empty($success) && !empty($failed)) {
        $summary_outcome = "<span color=\"#cc0000\">Not all files have been repaired.</span>";
    } else {
        $summary_outcome = "<span color=\"#cc0000\">Unable to repair permissions.</span>";
    }

    if (!empty($success) && !empty($failed)) {
        $summary_lists = "<p><strong>Successful:</strong><br/><pre style=\"max-height: 200px; overflow: auto;\">" . implode("\n", $success) . "</pre><p><strong>Failed:</strong><br/><pre style=\"max-height: 200px; overflow: auto;\">" . implode("\n", $failed) . "</pre>";
    } elseif (!empty($success)) {
        $summary_lists = "<pre>" . implode("\n", $success) . "</pre>";
    } else {
        $summary_lists = "<pre>" . implode("\n", $failed) . "</pre>";
    }

    echo '
    <center style="background-color: #04115f"><img src="chmod.gif" alt="chmod"></center>
    <p><strong>' . $summary_outcome . '</strong></p>
    ' . $summary_lists . '
    <div style="text-align: right"><button type="button" class="btn btn-default" onClick="javascript:window.close(\'\',\'_parent\',\'\');">Close</button></div>
    ';

}


include 'includes/fileactions_footer.php';