<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
example file action to make hardlinks local or remote over ssh
*/


// override debug output in fileactions include file
$fileactions_debug = FALSE;

include 'includes/fileactions.php';
include 'includes/fileactions_header.php';


// in this example we are running cp -al command on all selected items on search results page
// you can set fileactions_debug to TRUE above for debug info to print out fileinfo array

// use ssh to get remote directory
$use_ssh = false;
// ssh user and host
$ssh_host = "user@hostname";
$ssh_port = 22;
$ssh_verbose = false;
// path to ssh identity key file
$ssh_identity_file = "../../src/diskover/ssh_key.pem";


function isValidSourcePath($path) {
    /*
	Determine if the source path is valid to be used as a hardlink source
	Returns: array(isValid:bool, reason:str)
	*/
    if (!file_exists($path)) {
        return array(false, "Source path does not exist");
    } elseif (!preg_match('/^\/Volumes\//', $path) || !strpos($path, '/HA/')) {
        return array(false, "Source must be in a 'HA' folder on a SAN volume");
    } else {
		return array(true, "Path accepted");
    }
}

function getDestPath($path) {
	/*
	Determine the destination path from the source
	Returns: path_dest:str
	*/
    $split_source = explode('/', $path);

	$path_sanvolume = implode('/', array_slice($split_source, 0, array_search('HA', $split_source)));
    $path_basepath  = $path_sanvolume . '/NHA/HL';
    $path_fullpath  = $path_basepath . '/' . basename($path);

    if (!file_exists($path_basepath)) {
        throw new Exception("SAN volume does not contain a NHA/HL folder");
    } elseif (file_exists($path_fullpath)) {
        throw new Exception("A hardlink called \"" . basename($path) . "\" already exists");
    }

	return $path_fullpath;
}


if (empty($_POST)) {
    $paths_approved = array();
    $paths_links = array();
    $paths_failed = array();

    // Validate paths
    foreach ($fileinfo as $file) {
        $fullpath = $file['fullpath'];
        list($is_valid, $reason) = isValidSourcePath($fullpath);
        if ($is_valid) {
            $paths_approved[] = $fullpath;
        } else {
            $paths_failed[] = array($fullpath, $reason);
        }
    }

    // Determine link locations
    foreach ($paths_approved as $fullpath) {
        try {
            $paths_links[] = getDestPath($fullpath);
        } catch(Exception $e) {
            // Remove from lists and add to failed
            unset($paths_approved[array_search($fullpath, $paths_approved)]);
            $paths_failed[] = array($fullpath, $e->getMessage());
        }
    }

    // Show form to confirm from user
    echo '<div class="container">
    <div class="well">
    <form class="form-horizontal" name="confirmform" method="post" action="'.htmlspecialchars($_SERVER["PHP_SELF"]).'">
    <input type="hidden" name="submit" value="true">
    ';
    if (sizeof($paths_approved) > 0) {
    echo '
    <p><strong>Are you sure you want to hardlink the following path(s):</strong></p>
    <pre style="max-height: 200px; overflow: auto;">';
    foreach ($paths_approved as $key => $file) {
        echo "<hr/><strong>Src:</strong> " . $file . "<br/><strong>Dst:</strong> " . $paths_links[$key] . "\n";
    }
    echo '</pre><hr/>';
    }
    if (sizeof($paths_failed) > 0) {
    echo '
    <p><strong>The following paths cannot be hardlinked:</strong></p>
    <pre style="max-height: 200px; overflow: auto;">';
    foreach ($paths_failed as $file) {
        echo "<span style=\"color: #ff6347;\">" . $file[1] . ":</span>\t" . $file[0] .  "<br/>\n";
    }
    echo '</pre><hr/>';
    }
    echo '
    <div style="text-align: right;">';
    if (sizeof($paths_approved) > 0) {
    echo '
    <button type="submit" class="btn btn-primary">Yes</button>
    <button type="button" class="btn btn-default" onClick="javascript:window.close(\'\',\'_parent\',\'\');">Cancel</button>
    ';
    } else {
    echo '
    <button type="button" class="btn btn-default" onClick="javascript:window.close(\'\',\'_parent\',\'\');">Close</button>
    ';
    }
    echo '
    </div>
    </form>
    </div>
    </div>';
} else {
    // form submitted, run make hardlink command
    $succcess = array();
    $failed = array();

    foreach ($fileinfo as $file) {
        $fullpath = $file['fullpath'];
        // uncomment below and set to translate paths
        //$path_translations = array(
        //    '/^\//' => '/mnt/'
        //);
        //$fullpath = translate_path($fullpath, $path_translations);

        // get destination path for hardlink
        $fullpath_link = getDestPath($fullpath);

        // escape string for shell arg
        $fullpath_esc = escapeshellarg($fullpath);
        $fullpath_link_esc = escapeshellarg($fullpath_link);

        // run cp command on fullpath
        $cmd = 'sudo cp -al ' . $fullpath_esc . ' ' . $fullpath_link_esc . ' 2>&1';

        // use ssh to get remote directory
        if ($use_ssh) {
            $verbose = ($ssh_verbose) ? "-v" : "";
            $cmd = 'ssh -x "-o StrictHostKeyChecking=no" ' . $verbose .' -p '.$ssh_port.' -i '.$ssh_identity_file.' '.$ssh_host.' "' . $cmd . '"';
        }

        // run exec and get output and return value
        $output = $retval = null;
        exec($cmd, $output, $retval);

        // print html output
        echo '
        <div class="container-fluid cmd-output">
        Command: ' . $cmd . '<br>
        Status:<br>
        <pre>' . $retval .'</pre>
        Output:<br>
        <pre>' . implode("\n", $output) . '</pre>
        </div>
        ';

        // check return value and add path to failed or success arrays
        if ($retval !== 0) {
            $failed[] = array($fullpath, $fullpath_link);
        } else {
            $success[] = array($fullpath, $fullpath_link);
        }
    }

    // print html summary
    if (!empty($success) && empty($failed)) {
        $summary_outcome = "All paths have been hardlinked.";
    } elseif (!empty($success) && !empty($failed)) {
        $summary_outcome = "<span color=\"#cc0000\">Not all files have been hardlinked.</span>";
    } else {
        $summary_outcome = "<span color=\"#cc0000\">Unable to hardlink files.</span>";
    }

    if (!empty($success) && !empty($failed)) {
        $summary_lists = "<p><strong>The following paths have been hardlinked:</strong></p>";
        $summary_lists .= "<pre style=\"max-height: 200px; overflow: auto;\">";
        foreach ($success as $file) {
            $summary_lists .= "<hr/><strong>Src: </strong>" . $file[0] . "<br/><strong>Dst: </strong>" . $file[1] . "\n";
        }
        $summary_lists .= "</pre><hr/>";
        $summary_lists .= "<p><strong>Unable to make links for:</strong></p>";
        $summary_lists .= "<pre style=\"max-height: 200px; overflow: auto;\">";
        foreach ($failed as $file) {
            $summary_lists .= "<hr/><strong>Src: </strong>" . $file[0] . "<br/><strong>Dst: </strong>" . $file[1] . "\n";
        }
        $summary_lists .= "</pre><hr/>";
    } elseif (!empty($success)) {
        $summary_lists = "<p><strong>The following paths have been hardlinked:</strong></p>";
        $summary_lists .= "<pre style=\"max-height: 200px; overflow: auto;\">";
        foreach ($success as $file) {
            $summary_lists .= "<hr/><strong>Src: </strong>" . $file[0] . "<br/><strong>Dst: </strong>" . $file[1] . "\n";
        }
        $summary_lists .= "</pre><hr/>";
    } else {
        $summary_lists = "<p><strong>Unable to make links for:</strong></p>";
        $summary_lists .= "<pre style=\"max-height: 200px; overflow: auto;\">";
        foreach ($failed as $file) {
            $summary_lists .= "<hr/><strong>Src: </strong>" . $file[0] . "<br/><strong>Dst: </strong>" . $file[1] . "\n";
        }
        $summary_lists .= "</pre><hr/>";
    }

    echo '
    <p><strong>' . $summary_outcome . '</strong></p>
    ' . $summary_lists . '
    <div style="text-align: right"><button type="button" class="btn btn-default" onClick="javascript:window.close(\'\',\'_parent\',\'\');">Close</button></div>
    ';

}


include 'includes/fileactions_footer.php';