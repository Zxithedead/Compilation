#!/usr/bin/env python3
"""
diskover
https://diskoverdata.com

Copyright 2017-2021 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/


Find and print file sequences in a directory

Requires clique and elasticsearch python modules
https://gitlab.com/4degrees/clique
https://clique.readthedocs.io/en/stable/


Settings are stored in <diskover-web root>/src/diskover/filesequence_settings.py
Default/sample settings are in filesequence_settings.py.sample

Requires Media Edition license

"""

from elasticsearch import Elasticsearch
import sys
import os
import clique
import re
import time
sys.path.insert(1, '../../src/diskover')
try:
    import filesequence_settings as config
except ModuleNotFoundError:
    print('file sequence settings file not found!')
    sys.exit(1)

version = '0.0.5'
__version__ = version

badfiles = []

def get_file_seq(item, item_type, index):
    """Get file sequence from searching ES index."""
    if item_type == 'file':
        dir = os.path.dirname(item)
        filename = os.path.basename(item)
        filename_noext, ext = os.path.splitext(filename)
        ext = ext.lstrip('.')
        filename_nodigits = re.sub("[0123456789].*$", "", filename_noext).strip()
        filename_nodigits = escape_chars(filename_nodigits)
        
        query = {
            "size": config.size,
            "query": {
                "query_string": {
                    "query": "parent_path:\"" + dir + "\" AND extension:\"" + ext + "\" AND name:" + filename_nodigits + "* AND type:file",
                    "analyze_wildcard": "true"
                }
            }
        }
    else:
        filename = None
        
        query = {
            "size": config.size,
            "query": {
                "bool": {
                    "must": [
                        {
                            "match": {
                                "type": 'file'
                            }
                        },
                        {
                            "match": {
                                "parent_path": item
                            }
                        }
                    ]
                }
            }
        }
        
        if config.extensions is not None:
            query['query']['bool']['should'] = []
            for ext in config.extensions:
                ext = ext.lstrip('.')
                query['query']['bool']['should'].append(
                        {
                            "match": {
                                "extension": ext
                            }
                        }
                )
    
    # search ES index
    es = Elasticsearch(
        hosts=[
            {
                'host': config.host,
                'port': config.port,
                'scheme': config.scheme,
                'http_auth': (config.user, config.password)
            }
        ],
        timeout = config.timeout
    )
        
    # search for all files in directory
    resp = es.search(
        index=index,
        scroll='1m',
        size = config.size,
        body = query
    )
    
    scroll_id = resp['_scroll_id']
    
    images = []
    while len(resp["hits"]["hits"]) > 0:
        for hit in resp["hits"]["hits"]:
            docsrc = hit['_source']
            ext = '.' + docsrc['extension']
            name = docsrc['name']
            #fullpath = os.path.join(docsrc['parent_path'], docsrc['name'])
            # check if extension in config extension list
            if config.extensions is not None and ext not in config.extensions:
                continue
            
            images.append(name)
            
            # find any bad files
            if filename is not None:
                if docsrc['size'] <= config.minsize:
                    badfiles.append((name, docsrc['size']))
            else:
                if config.extensions is not None and ext in config.extensions and docsrc['size'] <= config.minsize:
                    badfiles.append((name, docsrc['size']))
        
        resp = es.scroll(
            scroll_id=scroll_id,
            scroll='1m'
        )
        
        scroll_id = resp['_scroll_id']
                
    return images


def escape_chars(text):
    """This is the escape special characters function.
    It returns escaped path strings for es queries.
    """
    # escape any backslash chars
    text = text.replace('\\', '\\\\')
    # escape any characters in chr_dict
    chr_dict = {'\n': '\\n', '\t': '\\t',
                '/': '\\/', '(': '\\(', ')': '\\)', '[': '\\[', ']': '\\]', '$': '\\$',
                ' ': '\\ ', '&': '\\&', '<': '\\<', '>': '\\>', '+': '\\+', '-': '\\-',
                '|': '\\|', '!': '\\!', '{': '\\{', '}': '\\}', '^': '\\^', '~': '\\~',
                '?': '\\?', ':': '\\:', '=': '\\=', '\'': '\\\'', '"': '\\"', '@': '\\@',
                '.': '\\.', '#': '\\#', '*': '\\*', '　': '\\　'}
    text_esc = text.translate(str.maketrans(chr_dict))
    return text_esc


if __name__ == "__main__":
    try:
        item = sys.argv[1]
        item_type = sys.argv[2]
        index = sys.argv[3]
    except IndexError:
       print('Missing args')
       sys.exit(1)
    
    start_time_es = time.time()
    
    # get file sequence from es index
    files = get_file_seq(item, item_type, index)
    totalfiles = len(files)
    
    start_time_clique = time.time()
    
    # find and print all file sequences
    collections, remainder = clique.assemble(files)
    if len(collections) > 0:
        print('--- file sequences found ---')
        for collection in collections:
            print(collection)
    else:
        print('No file sequences found')
        
    if len(badfiles) > 0:
        print('--- possible bad files found ---')
        for file in badfiles:
            print(file)

    print('---------------------------')
    print('PATH: {}'.format(item))
    print('TOTAL FILE COUNT: {}'.format(totalfiles))
    print('TOTAL ES QUERY TIME: {} seconds.'.format(round(time.time() - start_time_es, 5)))
    print('TOTAL CLIQUE TIME: {} seconds.'.format(round(time.time() - start_time_clique, 5)))