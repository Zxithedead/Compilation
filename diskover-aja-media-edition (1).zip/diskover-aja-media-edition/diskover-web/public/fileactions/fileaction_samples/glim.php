<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2021 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
File action to load image/video file in Glim web ui
Requires Media Edition license
*/

// override debug output in fileactions include file
$fileactions_debug = FALSE;

include 'includes/fileactions.php';
include 'includes/fileactions_header.php';


// Glim web host url
$glimhost = "https://glim.domain.com";

// in this example we are loading image/video files in Glim and translating paths
// from diskover-web to Glim format
// you can set fileactions_debug to TRUE above for debug info to print out fileinfo array

// Translate diskover-web path to Glim path
function translate_glim_path($path) {
    $path_arr = explode('/', $path);
    $path_arr[1] = '::' . strtoupper($path_arr[1]);
    array_shift($path_arr);
    $path = implode('/', $path_arr);
    return $path;
}

foreach ($fileinfo as $file) {
    // skip any directories selected
    if ($file['type'] != 'file') {
        echo "Not a file";
        continue;
    }

    $fullpath = $file['fullpath'];
    // uncomment below and set to translate paths
    //$path_translations = array(
    //    '/^\//' => '/mnt/'
    //);
    //$fullpath = translate_path($fullpath, $path_translations);

    $glimpath = translate_glim_path($fullpath);
    
    $glimurl = $glimhost . '/?path=' . $glimpath;
    $glimurl_enc = $glimhost . '/?path=' . urlencode($glimpath);

    // open new browser tab/window for Glim
    echo '
    <script type="text/javascript">
    window.open("' . $glimurl_enc . '", \'_blank\');
    </script>
    <div style="padding:5px">Loading ' . $glimurl . ' in new window...<br>
    If it does not load, click <a href="' . $glimurl_enc . '" target="_blank">here</a>.</div>
    ';
}


include 'includes/fileactions_footer.php';