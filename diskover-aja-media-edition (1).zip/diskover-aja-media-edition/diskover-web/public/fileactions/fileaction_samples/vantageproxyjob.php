<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2021 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
File action to submit a job to a workflow (create proxy) in Vantage using Vantage rest api
Requires Media Edition license
*/

// override debug output in fileactions include file
$fileactions_debug = FALSE;

include 'includes/fileactions.php';
include 'includes/fileactions_header.php';


// Vantage web host rest api url
$vantagehost = "http://vantageapi.domain.com:8676/Rest";

// Default selected workflow
$defaultworkflow = "d5614514-4ee7-4d42-b018-b4cfddb71980";

// Workflows to display in form, or leave array empty to get all
$activeworkflows = [];

// Debug output
$vantage_debug = FALSE;


if (empty($_POST)) {
    // Show form to select workflow
    
    // Use curl to send request to Vantage api to get all Workflows
    $vantageurl = $vantagehost . '/Workflows';
    $curl = curl_init($vantageurl);
    curl_setopt($curl, CURLOPT_URL, $vantageurl);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    $resp = curl_exec($curl);
    curl_close($curl);

    $resp = json_decode($resp, true);

    // create workflows array for form
    $workflows = array();
    foreach ($resp['Workflows'] as $wf) {
        // check if workflow is in activeworkflows
        if (sizeof($activeworkflows) > 0 && array_search($wf['Identifier'], $activeworkflows) === false) {
            continue;
        }
        // check if workflow is modified in the last month
        if (time() > strtotime($wf['UTC_ModifiedTime'] . ' +1 months')) {
            continue;
        }
        $workflows[$wf['Identifier']] = $wf['Name'];
    }
    asort($workflows);

    echo '<div class="container">
    <div class="well">
    <form class="form-horizontal" name="idform" method="post" action="'.htmlspecialchars($_SERVER["PHP_SELF"]).'">
    <legend>Select a Vantage Workflow</legend>';
    foreach ($workflows as $key => $value) {
        echo '<div class="form-check">
        <label class="form-check-label">';
        if ($key == $defaultworkflow) {
            echo '<input type="radio" class="form-check-input" name="id" value="'.$key.'" checked> <span class="text-success">'.$value.'</span> <span class="text-muted">('.$key.')</span> <span class="label label-success">Default</span>';
        } else {
            echo '<input type="radio" class="form-check-input" name="id" value="'.$key.'"> '.$value.' <span class="text-muted">('.$key.')</span>';
        }
        echo '</label>
        </div>';
    }
    echo '<br><button type="button" class="btn btn-default" onClick="javascript:window.close(\'\',\'_parent\',\'\');">Cancel</button>
    <button type="submit" class="btn btn-primary">Submit</button>
    </form>
    </div>
    </div>';
} else {
    // form submitted, submit job to Vantage

    // Vantage Workflow ID from form submit
    $vantage_workflow_id = $_POST['id'];

    // REST call to desired Vantage Workflow
    $vantageurl = $vantagehost . '/Workflows/' . $vantage_workflow_id . '/Submit';

    // in this example we are using the Vantage rest api to submit a job to a workflow and
    // create a new proxy job
    // you can set fileactions_debug to TRUE above for debug info to print out fileinfo array

    foreach ($fileinfo as $file) {
        // skip any directories selected
        if ($file['type'] != 'file') {
            echo "Not a file";
            continue;
        }

        $filename = $file['source']['name'];

        $fullpath = $file['fullpath'];
        // uncomment below and set to translate paths
        $path_translations = array(
        //    '/^\//' => '/mnt/',
        //    '/^\//' => '//uncstor/',
            '/^\/mnt' => '//uncstor',
        //    '/^\/s3-bucket/' => 's3://access_key:secret_key@s3.amazonaws.com/s3-bucket'
        );
        $fullpath = translate_path($fullpath, $path_translations);

        // check for s3 path
        if (strpos($fullpath, 's3://') === FALSE) {
            $IS_S3 = false;
            // replace forward slashes with backslash (Windows path)
            $fullpath = str_replace('/', '\\', $fullpath);
        } else {
            // add extra s3 url params
            $IS_S3 = true;
            $fullpath .= '?region=us-west-1&timeout=300';
        }

        // replace forward slashes with backslash (Windows)
        $fullpath = str_replace('/', '\\', $fullpath);

        // set Vantage job name to filename without extension
        $jobname = preg_replace('/\\.[^.\\s]{3,4}$/', '', $filename);

        // add logged in username to jobname
        $jobname = $jobname . '__' . $_SESSION['username'];

        // Use curl to send request to Vantage api
        $curl = curl_init($vantageurl);
        curl_setopt($curl, CURLOPT_URL, $vantageurl);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_TIMEOUT, 10);

        $headers = array(
        "Accept: application/json",
        "Content-Type: application/json",
        );
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

        $data = [
            'Attachments' => [],
            'JobName' => $jobname,
            'Labels' => [],
            'Medias' => [
                [
                    'Identifier' => 'abb3f7e5-8d7e-49ba-84c5-674a55edb700',
                    'Data' => 'If sending in-band data (eg: CML); place a UTF8 BASE64 encoded version of the data in this field and do not send a file path.',
                    'Description' => 'The original version of content encountered or created by Vantage.',
                    'Files' => [$fullpath],
                    'Name' => 'Original'
                ]
            ],
            'Priority' => 0,
            'Variables' => []
            /*'Variables' => [
                [
                    'Identifier' => '765cd13d-4807-4c05-bf9b-b0206074c978',
                    'DefaultValue' => '00:00:00:00@29.97',
                    'Description' => '',
                    'Name' => 'Glimpse - Marker 1 In',
                    'TypeCode' => 'TimeCode',
                    'Value' => $markin
                ],
                [
                    'Identifier' => 'b58ea50f-3512-49e2-a218-f4afb9f99639',
                    'DefaultValue' => '00:00:00:00@29.97',
                    'Description' => '',
                    'Name' => 'Glimpse - Marker 1 Out',
                    'TypeCode' => 'TimeCode',
                    'Value' => $markout
                ],
                [
                    'Identifier' => '1308d16b-0657-4d8d-ac6c-f9e66381c8b7',
                    'DefaultValue' => '',
                    'Description' => 'The name of a file (without path).',
                    'Name' => 'File Name',
                    'TypeCode' => 'String',
                    'Value' => $outputname
                ]
            ]*/
        ];

        $data_json = json_encode($data);

        curl_setopt($curl, CURLOPT_POSTFIELDS, $data_json);

        $resp = curl_exec($curl);
        $httpcode = curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        curl_close($curl);

        echo '<div class="container-fluid cmd-output">';
        // hide auth info for s3 path
        if ($IS_S3) {
            echo "Submitted " . $filename . "<br>";
        } else {
            echo "Submitted " . $fullpath . "<br>";
        }
        if ($vantage_debug) {
            echo "Vantage REST url: " . $vantageurl . "<br>";
            echo "JSON data:<br>";
            echo "<pre>";
            print_r(json_decode($data_json, true));
            echo "</pre>";
            echo "<br>";
            echo "Vantage HTTP code: " . $httpcode . "<br>";
        }
        echo "Vantage response:<br>";
        echo "<pre>";
        print_r(json_decode($resp, true));
        echo "</pre>";
        if (isset($resp['JobIdentifier']) && $resp['JobIdentifier'] == '00000000-0000-0000-0000-000000000000') {
            echo "ERROR - JOB NOT CREATED<br>";
        }
        echo "done<br>";
        echo "</div>";
    }
}


include 'includes/fileactions_footer.php';