/*
diskover-web
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
Name: liveview.js
liveview.js file for Live View File Action
*/

// location of ajax url to scandir.php, can be file path or http(s) url to scandir.php
//var scandir_url = 'https://<web server>:<port>/scandir.php';
var scandir_url = 'liveview/scandir.php';
// for web server to web server communication using php cURL instead of web browser ajax to remote web server use remotescandir.php
//var scandir_url = 'liveview/remotescandir.php';


$(document).ready(function () {
    // live view data table
    var lvpath = getCookie('liveviewpath');

    var table = $("#liveview-dirlist").DataTable({
        'ajax': {
            'url': scandir_url,
            'data': {
                'path': lvpath
            },
            'cache': false,
            'error': function(xhr, resp, text) {
                if (text === 'timeout') {
                    text = 'Timeout getting directory list';
                }
                console.log(text);
                $("#error").show();
                $("#error").append(text);
             },
             'timeout': 60000  // 60 sec
        },
        "deferRender": true,
        'columns': [
            { data: 'name' },
            { data: 'path', 'visible': false },
            { data: 'size' },
            //{ data: 'size_du' },
            { data: 'mtime' },
            { data: 'atime' },
            //{ data: 'ctime' },
            { data: 'owner' },
            { data: 'group' },
            { data: 'type' },
        ],
        'stateSave': true,
        'lengthMenu': [10, 25, 50, 100, 200, 300, 500, 1000],
        'pageLength': 50,
        'columnDefs': [{
                'type': 'file-size',
                'targets': 2
            },
            {
                'targets': 1,
                render: function (data, type, row, meta) {
                    var html = '<span class="wrap"> ' + data + '</span>';
                    return html;
                }
            },
            {
                'targets': 0,
                render: function (data, type, row, meta) {
                    var path_enc = encodeURIComponent(row.path);
                    if (row.type == 'Directory') {
                        // html for directories
                        var html = '<span class="wrap"><a href="liveview.php?path='+path_enc+'"><i class="fas fa-folder" style="color:#8B949E; padding-right:6px; font-size:16px;"></i> ' + data + '</a></span>';
                    } else {
                        // html for files
                        var html = '<span class="wrap"><i class="far fa-file" style="color:#8B949E; padding-right:6px; font-size:16px;"></i> ' + data + 
                                    //'<div class="btn-group" style="display:inline-block; float:right;">' +
                                    //'<a href="#" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown" aria-expanded="false" title="file actions">' +
                                    //'<i class="fas fa-cogs"></i>' +
                                    //'<span class="caret"></span>' +
                                    //'</a>' +
                                    //'<ul class="dropdown-menu">' +
                                    //'<li><a style="text-decoration:none!important;" href="#">No file actions</a></li>' +
                                    //'<li><a style="text-decoration:none!important;" href="cat.php?path='+path_enc+'" target="_blank">Cat file</a></li>' +
                                    //'<li><a style="text-decoration:none!important;" href="md5.php?path='+path_enc+'" target="_blank">MD5 file</a></li>' +
                                    //'</ul>' +
                                    //'</div>' +
                                    '</span>';
                    }
                    return html;
                }
            }
        ],
        'language': {
            'emptyTable': 'No files found'
        },
        buttons: [
            {
                extend: 'copy',
                title: '',
                header: false,
                exportOptions: {
                    columns: 1
                }
            },
            'colvis', 'selectNone', 'selectAll'
        ],
        'select': true,
        initComplete : function () {
            table.buttons().container()
                .appendTo( '#liveview-dirlist_wrapper .col-sm-6:eq(0)' );
            
            $('input[type=search]').val(''); // Clear Search input.
            table.search('').draw(); // Rebind all data.
        }
    });
    
    $.fn.dataTable.ext.errMode = function ( settings, helpPage, message ) { 
        console.log(message);
        $("#error").show();
        $("#error").append(message); 
    };
});