<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
Name: scandir.php
scandir.php file for Live View File Action
Requires: php-posix extension (php-process)
*/

// accept cross-domain AJAX requests from any domain
// more secure to set domain instead of wildcard
//header('Access-Control-Allow-Origin: *');
//header('Access-Control-Allow-Origin: http://example.com');

// set php time limit for page to timeout
set_time_limit(60);

// Check for php-posix extension
if (!function_exists('posix_getuid')) {
    echo json_encode(array('error' => "scandir.php error: php-posix extension not found, install php-process and restart php-fpm service"));
    exit;
}

$fileinfo = array();
$gidLookup = array();
$uidLookup = array();

// get path from liveview.js datatable ajax data path param
if (isset($_GET['path'])) {
    $lvpath = $_GET['path'];
} else {
    $lvpath = "";
}

// Timezone for file times
// set to your local time zone https://www.php.net/manual/en/timezones.php
$timezone = 'America/Vancouver';

// Ignore if file or folder is hidden (starts with .)
$ignorehidden = TRUE;

// Directory item limit (max files/directories to show)
// Directory items are sorted by modified time
$itemlimit = 10000;

// Lookup user/group names for uid/gid
$usergroup_lookup = TRUE;

// Path translation for listing files
$path_translations = array(
    //  '/^\//' => '/mnt/'
);
$lvpath = translate_path($lvpath, $path_translations);

// Path translation for path copied to clipboard
$path_clipboard_translations = array(
    //  '/^\/mnt\//' => '/'
);


//Class to extend FileSystemIterator
class AdvancedFilesystemIterator extends ArrayIterator
{
    public function __construct(string $path, int $flags = FilesystemIterator::KEY_AS_PATHNAME | FilesystemIterator::CURRENT_AS_FILEINFO | FilesystemIterator::SKIP_DOTS)
    {
        parent::__construct(iterator_to_array(new FilesystemIterator($path, $flags)));
    }

    public function __call(string $name, array $arguments)
    {
        if (preg_match('/^sortBy(.*)/', $name, $m)) return $this->sort('get' . $m[1]);
        throw new MemberAccessException('Method ' . $methodName . ' not exists');
    }

    public function sort($method)
    {
        if (!method_exists('SplFileInfo', $method)) throw new InvalidArgumentException(sprintf('Method "%s" does not exist in SplFileInfo', $method));

        $this->uasort(function(SplFileInfo $a, SplFileInfo $b) use ($method) { return (is_string($a->$method()) ? strnatcmp($a->$method(), $b->$method()) : $b->$method() - $a->$method()); });

        return $this;
    }

    public function limit(int $offset = 0, int $limit = -1)
    {
        return parent::__construct(iterator_to_array(new LimitIterator($this, $offset, $limit))) ?? $this;
    }

    public function match(string $regex, int $mode = RegexIterator::MATCH, int $flags = 0, int $preg_flags = 0)
    {
        return parent::__construct(iterator_to_array(new RegexIterator($this, $regex, $mode, $flags, $preg_flags))) ?? $this;
    }

    public function ignoreHidden($ignorehidden, string $regex = '/^$/', int $mode = RegexIterator::MATCH, int $flags = RegexIterator::INVERT_MATCH, int $preg_flags = 0)
    {
        if ($ignorehidden) $regex = '/\/\..*$/';

        return parent::__construct(iterator_to_array(new RegexIterator($this, $regex, $mode, $flags, $preg_flags))) ?? $this;
    }
}

//Lookup username from UID and cache
function uidLookup($file)
{
    global $uidLookup;

    if (array_key_exists($file->getOwner(), $uidLookup)) {
        $owner = $uidLookup[$file->getOwner()];
    } else {
        $owner = posix_getpwuid($file->getOwner())['name'];
        $uidLookup[$file->getOwner()] = $owner;
    }
    return $owner;
}

//Lookup group from GID and cache
function gidLookup($file)
{
    global $gidLookup;

    if (array_key_exists($file->getGroup(), $gidLookup)) {
        $group = $gidLookup[$file->getGroup()];
    } else {
        $group = posix_getgrgid($file->getGroup())['name'];
        $gidLookup[$file->getGroup()] = $group;
    }
    return $group;
}

// set any path translations to find path if it's different in index from the real path
// from index path translations
// returns translated path
function translate_path($path, $path_translations = array())
{
    // return path if nothing to translate
    if (empty($path_translations)) return $path;

    foreach ($path_translations as $pattern => $replacement) {
        if (preg_match($pattern, $path)) {
            $path = preg_replace($pattern, $replacement, $path);
            break;
        }
    }
    return $path;
}

// convert utc iso timestamp to local time
function utcTimeToLocal($date)
{
    global $timezone;

    if ($date == null) {
        return "-";
    }
    if (getCookie('localtime') == "" || getCookie('localtime') == "0") {
        return $date;
    }
    $l10nDate = new DateTime($date, new DateTimeZone('UTC'));
    $l10nDate->setTimeZone(new DateTimeZone($timezone));
    return $l10nDate->format('Y-m-d H:i:s');
}

function getCookie($cname)
{
    $c = (isset($_COOKIE[$cname])) ? $_COOKIE[$cname] : '';
    return $c;
}

// human readable file size format function
function formatBytes($bytes, $precision = 1)
{
    if ($bytes == 0) {
        return "0 Bytes";
    }
    if (getCookie('filesizebase10') == '1') {
        $basen = 1000;
    } else {
        $basen = 1024;
    }
    $precision_cookie = getCookie('filesizedec');
    if ($precision_cookie != '') {
        $precision = $precision_cookie;
    }
    $base = log($bytes) / log($basen);
    $suffix = array("Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")[floor($base)];

    return round(pow($basen, $base - floor($base)), $precision) . " " . $suffix;
}


if (!empty($lvpath)) {
    // check directory exists and is readable
    if (!is_readable($lvpath)) {
        echo json_encode(array('error' => 'Directory ' . $lvpath . ' not found or is not readable.'));
        exit;
    }
    try {
        foreach ((new AdvancedFilesystemIterator($lvpath))->sortByMTime()->ignoreHidden($ignorehidden)->limit(0, $itemlimit) as $file) {
            // Ignore symlinks
            //if ($file->isLink()) continue;

            $fileinfo[] = [
                'name' => $file->getFilename(),
                //'extension' => $file->getExtension(),
                //'parent_path' => $file->getPath(),
                'path' => translate_path($file->getPathname(), $path_clipboard_translations),
                'size' => ($file->isFile()) ? formatBytes($file->getSize()) : '--',
                //'size_du' => ($file->isFile()) ? formatBytes(stat($file->getPathname())['blocks'] * 512) : '--',
                'owner' => ($usergroup_lookup) ? uidLookup($file) : $file->getOwner(),
                'group' => ($usergroup_lookup) ? gidLookup($file) : $file->getGroup(),
                'mtime' => utcTimeToLocal(gmdate("Y-m-d\TH:i:s", $file->getMTime())),
                'atime' => utcTimeToLocal(gmdate("Y-m-d\TH:i:s", $file->getATime())),
                'ctime' => utcTimeToLocal(gmdate("Y-m-d\TH:i:s", $file->getCTime())),
                //'nlink' => stat($file->getPathname())['nlink'],
                //'ino' => $file->getInode(),
                //'unix_perms' => substr(sprintf('%o', $file->getPerms()), -4),
                'type' => $file->getType() == 'file' ? 'File' : 'Directory'
            ];
        }
    } catch (Exception $e) {
        echo json_encode(array('error' => $e->getMessage()));
        exit;
    }
}

echo json_encode(array('data' => $fileinfo));
