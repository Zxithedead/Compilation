<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

// file actions header include file

?>

<!DOCTYPE html>
<html lang="en">

<head>
   <?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
   <!-- Global site tag (gtag.js) - Google Analytics -->
   <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
   <script>
   window.dataLayer = window.dataLayer || [];
   function gtag(){dataLayer.push(arguments);}
   gtag('js', new Date());

   gtag('config', 'G-NDFBQ1BYMH');
   </script>
   <?php } ?>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>diskover &mdash; <?php echo (isset($fileactions_pagetitle) && !empty($fileactions_pagetitle)) ? $fileactions_pagetitle : 'File Action' ?></title>
   <link rel="stylesheet" href="../css/fontawesome-free/css/all.min.css" media="screen" />
   <link rel="stylesheet" href="../css/bootswatch.min.css" media="screen" />
   <link rel="stylesheet" href="../css/diskover.css" media="screen" />
   <link rel="stylesheet" href="../css/diskover-fileactions.css" media="screen" />
   <link rel="icon" type="image/png" href="../images/diskoverfavico.png" />
   <?php echo (isset($fileactions_header_inc)) ? $fileactions_header_inc : '' ?>
</head>

<body>