# Diskover-web v2 Change Log

# [2.1.0] - 2023-02-06
### fixed
- not staying logged in when checking keep me logged in for 7 days on login page
- Cross-Site Scripting (XSS) vulnerability in nav.php
- license issue
- issue with smartsearches, tags, costs analytics pages and checking show directories only and no results causes page to load with "Sorry, no smart search results found in the index(s)" and unable to set back and see charts
- issue with tags analytics page showing "Sorry, no tags found in the index(s)" and unable to see charts
- issue with showing charts by count
- INDEX_MAPPINGS excluded_dirs config setting not being recursive for the directory path
- Fatal error: Allowed memory size of n bytes exhausted in Diskover.php when searching for /nonexistpath
- es search query error when searching for /nonexistpath
- bug fixes searching full absolute paths
- php timeout when exporting large csv/json files
- double quotes not displaying in task panel form input fields in tasks
- links on dashboard not loading root path in search results
- filters for hardlinks not using nlink field
- searching "NOT parent_path:\/somepath" changing the directory in file tree
### added
- Reports page (Pro +) - custom reporting analytics page
- more options to quick search nav menu dropdown
- more options to filters modal
- filter charts checkbox to nav filters button modal and settings page to apply filters to search results and dashboard charts
- reports link to nav analytics drop down menu and path drop down menus
- ldap groups/index mapping paths filtering to smart searches, user analysis, and cost analysis
- show error link on edit smart searches, edit cost analysis pages
- show multi-fields on help page fields section and filter fields, e.g. media_info.framerate
- diskspace api example to help page
- additional file action samples: cat.php, md5.php
- path url param check to fileactions.php include file
- reload button to bottom of dashboard page to reload chart data
- Hash Diffs file action to fileaction_samples directory
- New Files file action to fileaction_samples directory
- css to wrap long text for extra fields on search results table
- waiting (run now) and stopping (stop task) last status icons/text to task panel task list page table
- no index selected warning message on indices page
- excluded_query key to INDEX_MAPPINGS config setting
    - added example usage in default/sample config file Constants.php.sample
- edit search query button to search results page
- fileactions_pagetitle var to fileactions_header.php include file to set html page title for file action
- fileactions_header_inc var to fileactions_header.php include file to add addtional header html for file action
- fileactions_footer_inc var to fileactions_footer.php include file to add addtional footer html for file action
- "LDAP_GROUPSDN" config settings to Constants.php.sample and config defaults, copy to your Constants.php config
### changed
- removed search path from filters
- removed filters always being applied to search results charts
- charts on dashboard and search page
    - now use analytics size and time filters set in Constants.php and analytics pages
    - display size/count on mouse over tips
- top by count charts now display by doc counts rather than counts of top by size chart data
- all links on analytics pages open in new browser tab
- removed need for escaped path separators, spaces, unc paths when creating new task in task panel
- updated api to v2.0.5
    - added diskspace endpoint to get disk space info from spaceinfo docs in index
- updated Live View File Action to v0.1.8 (in fileaction_samples directory)
    - fixed issue with using url for scandir.php
    - added file actions menu example for files (commented out in liveview.js)
    - added liveview.css and text wrapping for long file names/paths
    - added scandirremote.php for web server to web server communication of directory lists
    - improved timeout handling
    - set directory item limit to 10,000 items in scandir.php, items are sorted by newest modified time (mtime)
    - added setting at top of scandir.php for uid/gid name lookups
    - moved php-posix extension check into scandir.php from liveview.php
- removed checkurlparams from fileactions.php include file (no longer used by file actions)
- improved file tree on File Tree and Treemap analytics pages
    - arrow icon next to folder is no longer shown if folder has no sub dirs and show files is disabled
- all chart links on dashboard and search page now open in new window
- find similiar, view file/directory info buttons, and search path menu items on search results page table now open in new window
- links on view file/directory info page now open in new window
- exporting csv/json files now opens new browser window, changed php timeout to 10 min
- removed File Action Task from task panel


# [2.0.7] - 2022-12-04
### fixed
- searches using multiple parent_path fields does not return results from multiple indices
- toggling current top path only in tags or cost analysis pages shows no tags/no cost data found in the index and unable to toggle current top path only
- tables not display correctly on user analysis page when no cost data in index
- issue showing no items found in search results when sort order set on a field that not all selected indices have
- issue with UNIXPERMS_FILTERING_ENABLED set to TRUE in config
- php warning when reloading indices and there is a corrupt index
- added check in smart searches edit page for exclamation ! at start of smart search name
### added
- current directory only toggle button to smart searches, user analysis, tags, cost analysis pages
- load path in smart searches, user analysis, tags, cost analysis pages to path dropdown button on search results and view info pages
- user alert when trying to sort on a field not found in index or trying to sort on a text field
- cli options/flags input field to index task form in Task Panel
- date/time to export file name
- indication of how many indices selected on select indices page
- number and name of indices to delete confirmation on select indices page
- example indexing tasks to tasks.json.sample and templates.json.sample
### changed
- when exporting to csv file, any array fields (e.g. media_info, tags) now have separate columns for each sub-field (e.g. media_info.resolution, tags.0)
- updated api to v2.0.4
    - added totalhits to return json for search and tags endpoints
- made show files only toggle checkbox the default on smart searches, tags, cost analysis pages


# [2.0.6] - 2022-11-06
### fixed
- issue searching for full paths to hidden dot files/folders and files with double extensions (e.g. tar.gz)
- issue searching for full file path
- issue with rootpath not updating and directory searches showing no results
- ldap debug output
- es search error [ids] unknown field [type]
- show all not being toggled/checked on by default on tags, smart searches, cost analysis pages
- issue with smart searches, tags, cost analysis pages links not searching across all indices and search results not matching values on analytics pages
- issue with cost analysis and current top path only toggle not being used when clicking links for search query results
- issue with cost analysis and clicking links not url encoding search query
- occasional php fatal error when search contains parent_path field
### added
- reduced search time when searching for paths
- checkurlparams to fileactions.php include file
    - can be used in file actions to not enforce url params (docid, docindex) check
- diskover.js javascript to file actions include file fileactions_footer.php
- comma separated $ values to cost analysis page
- Live View v0.1.3 file action (enhanced listdir) in fileaction_samples directory
- help text to cost analysis, smart searches, tags edit pages
### changed
- set LDAP_USERSDN in default/sample config Constants.php.sample to empty string to search across whole domain for user


# [2.0.5] - 2022-10-21
### fixed
- rootpath not getting set correct for multi-toppath indices
- changing index in url params doesn't set the index or root path
- other minor bug fixes and improvements
### added
- ES_SSLVERIFICATION setting to default/sample web config file src/Constants.php.sample, copy to your config and set for your env
    - ssl and certificate verification when connecting to ES
- HIDE_SHAREDATA setting to default/sample web config file src/Constants.php.sample, copy to your config and set for your env 
### changed
- updated api to v2.0.3
    - set es search scroll context to 30s instead of 1m


# [2.0.4-1] - 2022-10-11
### UPDATE 1
### fixed
- slow logins from searching across all indices and es query type:(file OR directory)
- issue with ldap logins
### changed
- when logging in only the active top path index is searched rather than across all indices and search query is set to the active top path rather than type:(file OR directory)


# [2.0.4] - 2022-10-05
### BREAKING CHANGES
- LDAP_USERSDN config setting is required for ldap logins, see default/sample config file src/diskover/Constants.php.sample, update your config with these changes and set to your ldap users dn
- removed LDAP_ALT_BIND_USERS_DN from config, replaced with new config setting LDAP_USERSDN, see default/sample config file src/diskover/Constants.php.sample, update your config with these changes
### fixed
- issue when searching for a path using absolute path or parent_path index field, tree and charts not updating on search results page
- issue with using multiple browser tabs and not staying logged in
- having multiple browser tabs open and not being automatically logged out of all tabs when session timeout expires
- php ES error: Trying to create too many scroll contexts. Must be less than or equal to: [500]
- searching smart search containing quotes returning no results from quotes getting removed in query
- share search query containing spaces, etc characters not getting escaped when copying to clipboard
- searching a directory that is different than active top path doesn't switch the top path if the directory is in a different top path
- clicking on a search results page button with a large number would cause PHP to crash
- file charts being displayed on search results page when directory contains no files
### added
- saved queries menu item to Quick search nav button dropdown
- buttons to add and remove (next to search query) your favorite queries to saved queries menu list
- number of users drop down button to user analysis page to change numbers of users shown
- support for nested ldap groups
    - LDAP_NESTED_GROUPS setting to default/sample config file src/diskover/Constants.php.sample, copy to your config
    - LDAP_USERSDN setting to default/sample config file src/diskover/Constants.php.sample, copy to your config
- new config setting HIDE_SEARCH_CHARTS to hide search page charts by default to default/sample config file src/diskover/Constants.php.sample, copy to your config
- new config setting TOPPATH_LABELS to set a different label name for top path in search page file tree and top nav top path drop down to default/sample config file src/diskover/Constants.php.sample, copy to your config
### changed
- improved search page load times when searching directories, browsing using search file tree, and when using current directory only toggle
- reduced diskover-web search ES scroll time from 1m to 30s and clear scroll window after done searching
- improved user analysis page
- removed LDAP_ALT_BIND_USERS_DN from config, replaced with new config setting LDAP_USERSDN, see default/sample config file src/diskover/Constants.php.sample, update your config with these changes
- disabled search results page buttons > 1000 to prevent PHP crash


# [2.0.3] - 2022-09-19
### BREAKING CHANGES
- licensing changes
    - contact Diskover Data support@diskoverdata.com to get new license key file as existing diskover-web.lic file will no longer work
    - you will need to generate a new hardware id after updating before requesting new license keys https://docs.diskoverdata.com/diskover_installation_guide/#generating-a-hardware-id
### fixed
- bug with file actions using post form submit and multiple selected files
- select indices page selects multiple indices with similiar names even though not checked
- bug showing uuid change in nginx error log and web ui to not display latest index correctly when using always use latest index (auto-index)
- bug where path breadcrumbs in web ui disappears when index changes when using always use latest index (auto-index)
- bug with selecting different index with manual index selection with different top path doesn't change the top path
- bug with setting day of week in task to Sunday
- issue with customtags.txt file being opened multiple times on search results page
- bug with exports not exporting all search results when using a search query with OR
### added
- refer url redirection to login.php
- info messages on cost analysis, smart searches, and tags analytics pages when there are no ES search query results or .txt data files are empty
- fix permissions file action (fixperms.php) to fileaction samples directory
- make hardlinks file action (makehardlink.php) to fileaction samples directory
- error output to license check if license verify issue
- timeout setting for tasks
- ldap group info to fileactions debug output when file action not authorized to run by user
- extra Elasticsearch info to settings page
- all charts on search results page and dashboard are now clickable for searching results
### changed
- improved page load time on search results page when there are many tags
- updated api to v2.0.2
    - fixed get latest index endpoint returning es error if corrupt index
- separated version and license info on settings page
- removed change api password link on settings page for non-admin users
- removed elasticsearch and license info from settings page for non-admin users
- removed setting sort by size when clicking charts on search results and dashboard pages


# [2.0.2] - 2022-07-20
### fixed
- view file info page file and full path links not finding any search results when file name has double quote " in name
- api file read/write locking issue causing task json files to become empty
- file read/write locking issue with tasks json files
### changed
- updated api to v2.0.1
    - fixed file read/write locking issue with task json files
- updated file sequence file action plugin to v0.0.5 in fileaction_samples directory
    - reduced time assembling file sequences


# [2.0.1] - 2022-05-31
### fixed
- issue with fileaction containing form POST submit and multiple selected search results
- issue with active index top root path changing to current path directory when indices reload and always use latest indices is enabled
- issue with ldap logins and user being in both admin and regular user group and not being an admin after logging in
### added
- sqlite db checks
- LDAP_ALT_BIND2 config setting to Constants.php.sample to work with redhat idm/ipa


# [2.0] - 2022-04-04
### fixed
- php UTC timezone issue with task worker showing as offline and unknown state when diskoverd task worker first started
- php warning cannot sent header info on some task panel pages 
- not being redirected to login page when session expires and on task panel pages
- bool fields (like is_dupe) not showing as true or false on search results and view info page
- fixed adding new tag on search results page tag dropdown menu caused page to return no search results rather than refreshing page
- no docs showing for s3 indices when ldap/unix perms filtering enabled
- directories with trailing whitespace not returning any search results
- file file read/write locking issue on Windows for task panel/api
- can't find license file message occasionally on fileactions pages
- fileaction containing post form and after submission no selected file or directory message
### added
- longrunningscript.php to file action samples in public/fileactions/fileaction_samples/
### changed
- license for api to Essential +
- removed nginx directory


# [2.0-rc.5-1] - 2022-03-18
### fixed
- api issue with diskoverd and license bug


# [2.0-rc.5] - 2022-03-16
### BREAKING CHANGES
- new licensing
    - contact Diskover Data support@diskoverdata.com to get new license key file as existing diskover-web.lic file will no longer work
    - you will need to generate a hardware id before requesting new license keys https://docs.diskoverdata.com/diskover_installation_guide/#generating-a-hardware-id
    - features, file actions, etc which were previously unlocked, will now require a valid edition license (Essential, Pro, Media Edition, etc)
### fixed
- issues with analytics pages filter settings like size, maxdepth not getting set
- viewing tags page when nothing tagged didn't show info message that nothing was tagged
- multiple ES queries delay when typing text into search bar
- index fields getting added multiple times to filters and help page
- increasing MAX_INDEX setting in config not updating maxindex user browser cookie if set lower
- when setting use alternate config in index task, use default config does not get set to false after saving
- issue with select indices page and php warning message if new index not in cache
- mouse tooltip on nav bar path dropdown not showing top path
- issue with file action button next to file name not always using correct index/path if different search result items were previously selected
- heatmap change size column not sorting correctly
### added
- new licensing
- additional license info on settings page
- defaults for config
- filetree, treemap, and heatmap analytics pages auto-reload to redraw d3 charts on browser window resize
- DATABASE to default/sample config (Constants.php.sample), can be used to change sqlite database file path
- public/fileactions/fileaction_samples/ directory
### changed
- improved always use latest indices auto index selection
- improved table text wrapping on search results page
- improved UX and reduced queries to ES for file tree and tree map analytics pages
- removed public/lic.php, this file is no longer used
- if any missing config items are not in Constants.php (web config file), a default config value gets set and a message gets printed in web server error log
- updated api to v2.0-rc.4
- MAX_INDEX setting in default/sample config to 250
- increasing MAX_INDEX in config also increases it for all users who may have it set lower in browser cookie
- all sample file actions are now in public/fileactions/fileaction_samples/ directory


# [2.0-rc.4] - 2022-02-18
### BREAKING CHANGES
- added MAX_INDEX, INDEXINFO_CACHETIME, NEWINDEX_CHECKTIME settings to default/sample web config file, copy to your config file
- password for diskover and admin users required to be hashed and stored in separate sqlite db, you will be prompted to change password at next login, config passwords are just used for defaults
- api password now required to be hashed, change api password on settings page after logging in as admin to store in sqlite db, API_PASS in config is used as default password only and has to be changed before using api auth
### fixed
- reduced login time when many indices
- spinner loading icon not displaying on search results page for directory charts
- file action logs not wring to public/fileactions/ (missing logs directory)
- issue with not staying logged in and getting logged out before login time limit expires
- issue with always use latest indices and indices with multiple same top paths getting selected
- issue with user analysis page and clicking users or groups with domain names does not return search results
- issue with search results exports not using all set filters and sort order
- issue with extra field value text on file view info page not wrapping when text string is very long
- issue with extra field and object type not displaying correctly
- displaying error message when always use latest indices selected and an index gets deleted that is one of the latest indices
- heatmap displaying Nan value for reduced size on mouse tooltip
- issues with index aliases
- tags, smart searches, cost analytics pages not using size_du (allocated size) when set on settings page
### added
- MAX_INDEX, INDEXINFO_CACHETIME, NEWINDEX_CHECKTIME settings to default/sample web config file, copy to your config file
- max index setting to indices page
- change local user login password on settings page
- change api password on settings page
- tag all search results on all pages to tag drop down menu
- empty logs directory to public/fileactions/
- after deleting indices on select indices page, index list will reload automatically after 3 seconds
- optimized load time of user analysis page when cost data not stored in index
- Kibana file action sample web plugin
- primary/replica shard table columns to indices page
- Jquery ajax ajax.php.sample helper script for file actions (used by new file sequence file action)
- dir size no recurs toggle to tags, smart searches, cost analytics pages
    - show directory sizes not recursive for new indices that have size_norecurs and size_du_norecurs fields
### changed
- password for diskover and admin users required to be hashed and stored in separate sqlite db, you will be prompted to change password at next login
- reduced api calls to ES to check for new index info
- improved file/directory view info page for extra fields
- improved indices page
- updated api to v2.0-rc.3
    - fixed issue with latest endpoint and finding the latest index for indices with multiple top paths
    - api password now required to be hashed, change api password on settings page after logging in as admin to store in sqlite db, API_PASS in config is used as default password only and has to be changed before using api auth
- updated file sequence file action to v0.0.3
    - bug fixes
    - improved performance for large sequences
    - changed to using Jquery ajax ajax.php helper script
    - removed option to scan disk, only scan es index
    - updated default/sample settings file


# [2.0-rc.3] - 2021-12-27
### fixed
- select indices table, task panel tables not saving sort order or show number of entries setting on page reload
- directory info at top of charts not displaying when hide tree enabled on search results
- extra fields field description not displaying correctly on view file/directory info page
- extra fields not showing true or false for bool values on search results and view info page
- extra fields showing Array when ES doc field is an array of associated arrays (object type) on search results and view info page
- csv export bug with additional fields and data shifting if no field value
- csv export bug when ES doc field is an array of associated arrays (object type)
- issue with view info page file and full path links when file name contains spaces returning no search results
- clicking a tag with a + character in the tag name returned no search results
- issue with manual index selection and if the selected index is deleted while logged out, when trying to log in you are redirected to error page and cannot go to indices page
- nav bar top path drop down menu when many items would be longer than browser window causing some items to be hidden
- heatmap showing "NaN undefined" in Change table column for items that have reduced in size/count
### added
- link to Task Panel on error page if new install and there are no completed indices in ES
- AD/ldap group permission filtering settings to config file Constants.php.sample, copy to your config file
    - LDAP_FILTERING_ENABLED
    - LDAP_GROUPS_EXCLUDED
    - UNIXPERMS_FILTERING_ENABLED
- rclone file action example
- python script file action example
- Glim file action example
- python file sequence file action example
- percent on mouse over to search results and dashboard charts
- change size/count value column to heatmap table and mouse over
- documentation link to help page
- REST API HTTP Basic Auth settings to config file Constants.php.sample, copy to your config file
    - API_AUTH_ENABLED
    - API_USER
    - API_PASS
### changed
- improved search results ui
    - file tree is now fixed when scrolling
- updated Docker files to use linuxserver.io diskover docker container as base
- chart colors for items in bar and pie charts now match on dashboard and file search
- updated rest api to v2.0-rc.2
    - added HTTP Basic Auth
- moved File Actions config to Constants.php (config file), see Constants.php.sample (default/sample config file)
    - copy your file actions from Fileactions.php to Constants.php
    - removed src/diskover/Fileactions.php


# [2.0-rc.2] - 2021-10-19
### fixed
- issue when clicking on new file action task would cause error
- issue with search filters being applied to analytics pages (filetree, treemap, etc)
- issue when only single item on search results chart not showing bar in chart
- white screen/ error message if bad es query string syntax for smart searches or costs analysis
- issue with copy path button on search results when copying file with single quote in filename
### added
- redirect to edit page and warning if bad es query string syntax for smart searches or costs analysis
- stop task to task button dropdown menu (task panel)
- load average, worker pools, and versions columns on task workers page worker table (task panel)
- can assign tasks to worker pools (if any worker is assigned to a pool) (task panel)
- Windows command examples to create new task/edit task pages (task panel)
- new api endpoint "toppaths" usage to help page
- disk space bar chart next to drive icons in search results file tree
- better number formatting to smart searches and tags file counts
- find similiar button for each item in search results table
### changed
- set specific version of elastisearch php client in composer.json
- top paths (volumes) drive icons are now in a scrollable list if there are many 
- search results no items found message now shows file tree
- updated api to v2.0-rc.1
    - added new endpoints for diskoverd task worker
    - added new endpoint "toppaths" to get a list of top paths in an index


# [2.0-rc.1] - 2021-10-10
### note
- if upgrading from version older than v2.0-b.11, please see v2.0-b.11 changelog
### fixed
- clicking select all button on search results page caused all checkboxes to be selected including filters and current dir nav toggle checkbox
- issue with fileactions listdir not displaying all output
- issue with fileactions newsubdirs not displaying any output on Linux
- issue when force deleting index on select indices page
- issue with All extension button on search results page
- issue when enabling Current dir nav toggle, search query directory would not update when clicking file tree directory links
### added
- ES connection check if status code not 200
### changed
- all file actions example files renamed to fileactionname.php.sample
- switched google analytics to opt-in with setting on settings page


# [2.0-b.11] - 2021-09-30
### fixed
- issues with ES scrolling causing PHP ES client errors
- issue with indices page showing all index sizes as 0
- issue with share button and sharing search query paths are not escaped
- issue with no results showing in search results preview dropdown when current dir is active
- issue with analytics page filters (e.g. min file size) not getting set
- issue with csv exports showing "Array" for fields such as tags
- issue with csv exports and field name line not containing all possible search results field names
- issue with csv exports and empty fields showing as no value instead of null
- issue with aliases on select indices page
- issue with select indices page index table sorting
- issue with default search sort on settings page not setting sort cookies
- issue with exporting and using "current dir" nav toggle setting
- issues with exporting and files in search results don't match export files
### added
- support for searching across indices in different Elasticsearch clusters, see Constants.php.sample (sample web config file)
    - refer to Elasticsearch cross cluster search guide to set up remote clusters https://www.elastic.co/guide/en/elasticsearch/reference/7.x/remote-clusters.html
- additional config settings LDAP_ALT_BIND and LDAP_ALT_BIND_USERS_DN in Constants.php.sample (sample web config file) for altnerate ldap/ad bind method, copy to your Constants.php
    - needed by some ldap servers like freeipa/red hat idm to auth
- folder file/sub-directory tagging is now executed in the background as a php shell process (tagfiles_process.php)
- added additional date ranges to hot/cold data bar chart on dashboard and file search page
- notice modal popup when copying paths, etc to clipboard
- current top path only toggle button to tags, smartsearches, users, costs analytics pages to only show results for the current top path
- search query stays in search input after user submits search
- better error handling to notify user if index deleted, etc
- additional config setting SIZE_FIELD in Constants.php.sample for changing size field (size, size_du (allocated size)) used in charts and file tree, copy to your Constants.php
- use size_du allocated size option to settings page
- allocated sizes to dashboard for total files and total directories panels
- task panel task list and workers tables are now sortable and searchable
- form validation for tags, smartsearch and costs edit pages
- early support for File Actions (plugins)
- predictive search option to settings page to always use wildcard when searching
- improved tasks workers page
- addtional options to show max items dropdown menu on search results page
- config file sanity check to check no settings are missing from default/sample config
### changed
- renamed ES_HOST in config to ES_HOSTS and changed settings, see Constants.php.sample and edit your Constants.php config
- removed ES_PORT, AWS, AWS_HTTPS, ES_USER, ES_PASS settings from config, remove from your config and use new setting for ES_HOSTS
- improved settings page
- removed es stats for nerds on settings page
- updated api to v2.0-b.8
    - fixed issues with es scrolling
    - fixed issue with multiple es hosts in config
    - added support for additional config options when using multiple es hosts
    - fixed issues with tagfiles and tagdirs put actions and removing tags
- improved delay to display sub-folders in file tree and treemap analytics
- improved loading times for charts
- changed default use latest index enabled to TRUE in Constants.php.sample
- changed default login start page to filesearch in Constants.php.sample
- changed max dirs from 1000 to 100 for filetree and treemap analytics pages to improve load time
- removed hash from view filed/dir info page
- index mappings in config, see Constants.php.sample and copy to your Constants.php web config file
    - changed index_pattern key to index_patterns (list)
    - added index_patterns_exclude key
- recent searches is now only user input searches, not file tree link clicks
- tags, smartsearch and costs edit pages now open in new window


# [2.0-b.10] - 2021-08-26
### fixed
- issue on select indices page and form to select show indices newer than and index name contains not reloading indices and using cached indices
- issue on select indices page and deleting indices and reload indices link not clearing indices cache and reloading indices
- update links on select indices page not reloading indices and using cached indices
- issue with updated indices popup when entering in text in nav search bar
- issue with path bread crumb links on search results page when updated indices popup page reload
- issue with file search folder tree with space in folder names (appearing as + char) causing error folder size showing up on mouse over of folder icon
- issue with current dir only filter
- issue with corrupt index or index deleted (but in cache) causing php fatal http error 500
- issue with setting custom schedule on tasks using wildcard every n hours such as * */2 * * *
- issue with index task custom index name preview text showing non 0 padded date/time stamp numbers
- issue when editing tasks, existing task info for times, worker and status are not preserved
- issue with quick search not using doctype and searching both file and directory docs
- issue with dashboard links not using doctype and searching both file and directory docs
- issue with dashboard file type usage chart legend links not returning any search results
- issue with chart colors on tags page not matching tag color
- issue when file search is set as home page in config, cost data is not displayed and cost analysis does not load
- issue when using path translations on settings page and exporting copy selected paths to clipboard on search results page
- issue when setting file search as home page, costpergb does not get set and no cost data or cost analytics is displayed
- issue with index cache, indexing finishes but index info not updating even with index reload
- issue with searching for !smartsearch or #tag in search query that doesn't have matching smart search name or tag name would cause redirect to white background page
- settings browser cookies expiring after browser restart, set cookies to expire after 1 year
- issue with default hide fields in config file not being set when user logs in for first time
### added
- last new index check update time next to reload indices button in nav gear dropdown
- index top path indexing start time to search results page
- index name and indexing start time to search results tree green top path drive icons on mouse over tooltip
- mouse over tooltips to search results file tree buttons
- shift-select to search results table item select checkboxes and row highlighting
- copy file name to clipboard to export button on search results page and view file/directory info pages
- improved path translations for copy/paste
- EXTRA_FIELDS to Constants.php.sample, copy to your Constants.php (web config file)
- PATH_TRANSLATIONS to Constants.php.sample, copy to your Constants.php (web config file)
### changed
- select indices page now shows update time when indices were reloaded and not page refresh time
- task nav Back to Dashboard to Back to Home which takes you back to config login page
- updated api to v2.0-b.5
    - added new get call "latest" to get latest index from top path use with api.php/latest?toppath=/dirpath
    - fixed issues with task json files getting emptied occasionally
- removed popup box when new indices have been added (when always use latest indices set)
- removed popup box when copying paths, etc to clipboard
- set default session timeout to 8 hours before having to login again
- improved login page
- removed reload paths from nav paths dropdown menu
- removed extra fields from settings page and moved to Constants.php web config (see Constants.php.sample)
- path translations for copy/paste are now stored in Constants.php (see Constants.php.sample)
- removed extrafields.txt.sample
- extrafields.txt is no longer used and can be removed (moved to Constants.php, see Constants.php.sample)
- set default show indices newer than age to all on indices page


# [2.0-b.9] - 2021-07-07
### fixed
- bug with heatmap page setting index 1's indexname to same as index 2
- current path only search filter not working
- bug with Task Panel and new index task and setting an alternate config file path, needs to be directory containing config.yaml file
- issues with disabling task worker in Task panel
- dashboard's percent removable more info link, largest file/directory show more links and chart search links not using top active path in search
- bug where admin user could delete active in-use indices on select index page when more than one index 1
- remember me login checkbox not keeping user logged in
- issue where folders with more than 1000 subfolders did not show all subfolders in search results file tree (changed max dirs from 1000 to 5000)
- tree/chart data caching issues
- issue where paths were not getting reset when logging out
- elasticsearch host not showing at bottom of settings page
- slow page loading times when many indices
- adding ctime field as extrafield and setting show times in localtime did not show ctime field in local time
### added
- support for new diskover indices built with beta 9 indexer that have name.text and parent_path.text text type fields for full-text searching including case-insensitive searches using those field names
    - this should help to reduce heavy ES operations using wildcard * at start of queries
- new AD/LDAP settings in Constants.php.sample (default/sample web config file), copy to your web config file Constants.php
- search by file extension buttons to search results page
- running time to Task panel workers page
- reset sort link to no items found message on search results page
    - sorting by addtional field where no docs contain the additional field causes no items to be found when searching
- any extra fields added to hide fields on settings page
- more search examples on help page
- default login page setting LOGINPAGE to Constants.php.sample (default/sample web config file), copy to your web config file Constants.php
- default search results table hidden fields setting HIDE_FIELDS to Constants.php.sample (default/sample web config file), copy to your web config file Constants.php
- default display file/dir times in local timezone default setting LOCAL_TIMES to Constants.php.sample (default/sample web config file), copy to your web config file Constants.php
- new user/group index name/path mappings/filtering settings to Constants.php.sample (default/sample web config file), copy to your web config file Constants.php
    - settings to control what indices/paths each user/group (local or ldap) is allowed to view
- resizable search results table columns
    - reset table column widths button on settings page
- task panel task list show tasks with warning status for indices that complete but have warnings
- run now to task panel task button dropdown
- active top path to search path filters to filter only to the current top path
- exclude folders checkbox to search filters
- copy selected paths to export button menu on search results page
- improved search
    - improved results for wildcard * searching
    - keyword search only uses file name, parent path, and extension for finding items
    - can use lowercase "and", "or" instead of uppercase "AND", "OR" (default is OR when not using any and space between keywords)
    - improved full path searching of folders and files
- folder sizes to search results file tree
- support for up to PHP v7.4.20, recommended to update/upgrade (now default install version)
- nav current directory only toggle to only search within the current directory
- elasticsearch response time to bottom of settings page
- elasticsearch stats for nerds to bottom of settings page (admin users only)
- reload indices menu item to nav gear dropdown menu and button on select indices page to reload index data
- path breadcrumb links to search results page
### changed
- new indices are refreshed every 10 min, unless reload indices pressed
- select indices page index table files/sec to inodes/sec
- removed LDAP_USERSDN, OWN_FILES_ONLY and GROUP_FILES_ONLY from Constants.php.sample (default/sample web config file), remove from your web config file Constants.php
- removed current path only checkbox from quick search menu, moved to search filters
- task panel's new index task's alternate config from file to directory path
- updated api to v2.0-b.3
    - fixed issue with diskoverd updating task could cause tasks.json to be cleared
    - fixed issue with worker tasks not being updated
    - fixed issue with working time, successful task count and failed task count getting set incorrect
- Extension buttons on search results page now include any current search query
- Clicking tag icons on search results page now include any current search query
- Admin user is now required to change smart searches, editing or adding new custom tags, editing additional fields for search results on settings page
- improved search results page
- quick search uses "current dir only" toggle in nav
- share button to search results page to share current page or search query
- multiple top paths in search results file tree are now sorted by name in asc order, previously was by latest indexed
- search results file tree is now sorted by name in a more "natural ordering"
- updated PHP Client for Elasticsearch from v7.9.1 to v7.13.1 in vendor/ (composer package updates)
- search results page charts are no longer pre-loaded if set to hide
- search results tree directory is changed when path is searched using full path name
- when submitting search or changing folders in search tree, nav search input is unset
- set default show indices newer than to 2 weeks time on select indices page, previously was all


# [2.0-b.8] - 2021-05-11
### fixed
- reload button on search results page did not flush cache and reload tree data
- indexing top root path / would not show correctly in path dropdown or on file search tree
- select indices page where multiple top paths and their corresponding crawl times, file counts, etc are not matched correctly
- select indices page where not all start times show for indices with multiple top paths
- cost analysis and tags analytics pages clicking show files only then clicking one of the items for search doesn’t show just files, same for show directories only
- clicking on chart links on dashboard was not path aware when multiple top root paths
- path analytics button on search results and view info pages not loading analytics using all analytics filters
### added
- indices can now be selected and loaded even if not all paths in index are done indexing (for multi top path indices)
- check if Elasticsearch is running and display error message if not
- remove button on select index page to delete indices (for admin users only)
- filters button to nav bar to filter search results
- top extensions andcharts to search results page when clicking a path in tree
- Type colunm to search results page to allow sorting by file or directory
- different colors (blue/green) for sort and sort2 arrow buttons in search results table header
- default search sort to settings page
- charts for directories on search results page
- default index field names to help page
- support for index aliases and alias creation to select indices page
- alt scanner option to new index task
### changed
- improved search
- improved search results page
- improved sorting buttons on search results page
- improved select indices page
- improved settings page
- on search results pages the tagging button is disabled by default until a checkbox for a file/dir item is checked
- removed admin page
- removed advanced search page
- renamed simple.php to search.php
- moved notify of newer index to settings page
- when changing indices, you are not automatically redirected to dashboard
- removed recommended cleanup buttons from search drop down
- removed mouse right-click action from treemap and heatmap


# [2.0-b.7] - 2021-03-08
### fixed
- issue on select indices page for indexes with multiple top paths the "start time" was not showing the earliest start time of first path that was indexed
- quick search when searching for tags
- issue when going to select index page and then clicking file search button would cause path to not be found
- nginx config issue for api, see updated nginx diskover-web config on github wiki https://github.com/shirosaidev/diskover/wiki/Diskover-v2-Install-Guide and update your nginx diskover-web config
- elasticsearch regular expressions not working in search
- issue with clicking path links on file/dir view info page and path getting set incorrectly
### added
- Task Panel to schedule tasks for diskover daemon (diskoverd)
- public/tasks/ folder for all task related files
    - four .json.sample files, copy to .json file (remove .sample)
- file type usage chart to dashboard, file types can be changed in diskover-web config
- "Right Click" mouse button functionality to File tree, Tree map, Heat map analytics pages to open new window and search for path of mouse over item
- "current path only" checkbox to quick search menu to only search the active path/directory for quick search menu items
- TASK_PANEL_USERS to src/diskover/Constants.php.sample (diskover-web config) for controlling who has access to Task Panel, add to your Contants.php file
- improved search
### changed
- updated api to v2.0-b.2
    - added endpoints for scheduling tasks and work with diskover daemon (diskoverd)
    - changed tagfile to tagfiles, can now use multiple tags
    - changed tagdir to tagdirs, can now use multiple dirs and multiple tags
    - "list" endpoint now returns info for multiple paths in index
    - better handling of http and json responses/errors
- available space chart on dashboard, improved design
- select indices page to show more granular details for indexes with multiple top paths
- docker nginx config in nginx/conf.d/diskover-web.conf


# [2.0-b.6] - 2021-02-09
- changed "Mtime filter" to "Time filter" on analytics pages (time field to use can be set in Constants.php)
- added TIME and TIME_FIELD to Constants.php.sample, copy to your Constants.php
- removed MTIME from Constants.php.sample, remove from your config
- fixed issues with filter path button on search results and file view pages
- added "reset view" link to filetree/ treemap/ heatmap analytics pages "Sorry, no files found..." info box
- improved cost analysis page
- search buttons/ chart click search on filetree/ treemap analytics pages now use set min filesize/ time filters
- added "date changed" (ctime) to quick search and more date/ size options
- added "file type" to quick search (types set in diskover-web config Constants.php)
- added size and time filter buttons to search results page
- added extension search buttons to search results page
- fixed issue with exports when exported from advanced search
- added filetree to search results page
- added links for paths on file view info pages
- fixed issue with exporting large (many search results) csv/json files
- fixed issue with directories containing spaces
- fixed issue with filetree/treemap search buttons for directories in /
- fixed full path link on file view info page


# [2.0-b.5] - 2021-01-25
- added "Apply tags to" to tag drop down menu to allowing for tagging items recursively and non-recursively in directories
- improved formatting for extra fields (array or string) on view info and search results pages (extra fields added by crawler plugins)
- fixed issue with inode link on view file/directory info page
- improved tags analytics page
- improved smart searches analytics page
- improved top nav bar
- improved Quick search menu on nav bar
- improved select indices page
- fixed advanced search when searching for number of hardlinks (nlink) or 0 byte (empty) files or directories
- added cost to sort options on advanced search page
- fixed issue in file tree and tree map pages when switching between size and count and data not updating without having to click Reload button


# [2.0-b.4] - 2021-01-17
- fixed issue with dashboard and indexing / (root)
- fixed issue with tags not working on search results page
- fixed issue where not redirected to select index page when index being re-indexed and currently active
- added selected index1/ index2 to nav settings button tooltip on mouseover
- added "Notify when newer index" option to select indices page


# [2.0-b.3] - 2021-01-03
- fixed minor issues on select index page
- fixed bug where changing filters on filetree/ treemap page could cause page to not load
- fixed issue connecting to AWS ES
- improved ES query performance for time-based quick searches on nav


# [2.0-b.2] - 2020-12-19
- improved web ui nav bar
- added ability to search by current path only or any path in nav search
- added support to select multiple indices and search across more than one index in web ui
- fixed some minor issues with dashboard charts
- added path translation on settings page for copy path buttons
- added support for indices that have multiple top paths
- changed Last Modified chart on dashboard to Hot/Cold Data
- fixed issues with Heat map page
- improved Heat map page


# [2.0-b.1] - 2020-12-15
- first v2.0 beta release