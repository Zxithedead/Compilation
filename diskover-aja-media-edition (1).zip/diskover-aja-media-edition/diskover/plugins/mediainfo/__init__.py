#!/usr/bin/env python3
"""
diskover
https://diskoverdata.com

Copyright 2017-2022 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/


=== Plugin Name ===
diskover media info plugin

=== Plugin Description ===
diskover ffprobe video info plugin - This is an example plugin
for diskover. It adds extra video file meta data to diskover index
during indexing.

If any video file has an error with ffprobe, the file is tagged with
"mediainfo-plugin" and "bad-video" tags.

Media info is cached in sqlite3 db.

Example meta data that can be added https://gist.github.com/nrk/2286511

=== Plugin Requirements ===
- FFmpeg's ffprobe command (in PATH)
https://ffmpeg.org/

=== Diskover Indexing Plugins Requirements ===
all indexing plugins require six functions:
- add_mappings
- add_meta
- add_tags
- for_type
- init
- close

"""

import os
import sys
import shutil
import json
import subprocess
import time
import hashlib
import logging
import confuse
import datetime
import warnings
import re
from pathlib import Path

import diskover_cache as mi_cache
import diskover_lic


version = '0.0.19'
__version__ = version
__name__ = 'mediainfo_plugin'


"""Load yaml config file.
Checks for env var DISKOVER_MEDIAINFO_PLUGIN as alternate config file.
"""
config = confuse.Configuration('diskover_mediainfo_plugin', __name__)
config_filename = os.path.join(config.config_dir(), confuse.CONFIG_FILENAME)
if not os.path.exists(config_filename):
    print('Config file {0} not found! Copy from default config.'.format(config_filename))
    sys.exit(1)

# load mediainfo plugin default config file
config_defaults = confuse.Configuration('diskover_mediainfo_plugin', __name__)
scriptpath = os.path.dirname(os.path.realpath(__file__))
# get parent path two levels up
scriptpath_parent = Path(scriptpath).parents[1]
default_config_filename = os.path.join(scriptpath_parent, 'configs_sample/diskover_mediainfo_plugin/config.yaml')
config_defaults.set_file(default_config_filename)

def config_warn(e):
    warnings.warn('Config setting {}. Using default.'.format(e))

# laod config values
try:
    verbose = config['verbose'].get()
except confuse.NotFoundError as e:
    config_warn(e)
    verbose = config_defaults['verbose'].get()
try:
    extensions = config['extensions'].get()
except confuse.NotFoundError as e:
    config_warn(e)
    extensions = config_defaults['extensions'].get()
try:
    ff_timeout = config['ffTimeout'].get()
except confuse.NotFoundError as e:
    config_warn(e)
    ff_timeout = config_defaults['ffTimeout'].get()
try:
    bitrateformat = config['bitrateFormat'].get()
except confuse.NotFoundError as e:
    config_warn(e)
    bitrateformat = config_defaults['bitrateFormat'].get()
try:
    durationformat = config['durationFormat'].get()
except confuse.NotFoundError as e:
    config_warn(e)
    durationformat = config_defaults['durationFormat'].get()
try:
    frameratedecimals = config['framerateDecimals'].get()
except confuse.NotFoundError as e:
    config_warn(e)
    frameratedecimals = config_defaults['framerateDecimals'].get()
try:
    cachedir = config['cachedir'].get()
except confuse.NotFoundError as e:
    config_warn(e)
    cachedir = config_defaults['cachedir'].get()
try:
    cacheexpiretime = config['cacheexpiretime'].get()
except confuse.NotFoundError as e:
    config_warn(e)
    cacheexpiretime = config_defaults['cacheexpiretime'].get()
finally:
    if cacheexpiretime == 0: cacheexpiretime = None
try:
    excludedirs = config['excludedirs'].get()
except confuse.NotFoundError as e:
    config_warn(e)
    excludedirs = config_defaults['excludedirs'].get()
    

def ffprobe(file_path):
    """Run ffprobe command in subprocess and return json output, if error store error in metadata 
    that gets indexed."""
    cmd = ['ffprobe', '-v', 'quiet', '-print_format', 'json', '-show_format', '-show_streams', file_path]
    try:
        res = json.loads(
            subprocess.check_output(
            cmd,
            stderr=subprocess.STDOUT,
            timeout=ff_timeout))
    except subprocess.TimeoutExpired:
        # set metadata to contain timeout error if ffprobe times out
        res = {'error': 'timeout'}
    except subprocess.CalledProcessError as e:
        # set metadata to contain ffprobe error info if not output or other error
        # decode output
        out = e.output.decode('utf-8')
        # empty json output
        if out == '{\n\n}\n':
            res = {'error': 'no output'}
        else:
            res = {'error': out}
    finally:
        return res


def get_cached_media_info(file, stat):
    """Gets cached media info for file."""
    # hash file and see if it's stored in cache
    global micache
    pathhash = hashlib.md5(file.encode('utf-8')).hexdigest()
    res = micache.get_value(pathhash)
    if res and not 'error' in res['media_info']:
        # check if modified times are same
        if stat.st_mtime == res['mtime']:
            if verbose:
                mipluglogger.info('CACHE HIT {0}'.format(file))
            return res['media_info']
    # not in cache or mtime/size not same or error stored in cache
    if verbose:
        mipluglogger.info('CACHE MISS {0}'.format(file))
    # get media info from ffprobe
    metadata = ffprobe(file)
    # cache media info as long as there is no error
    if 'error' not in metadata:
        micache.set_value(pathhash, {'mtime': stat.st_mtime, 'media_info': metadata}, expire_seconds=cacheexpiretime, force_update=True)
    return metadata


def get_media_info(file_path, stat):
    """Returns media info text using ffprobe."""
    # get cached media info
    metadata = get_cached_media_info(file_path, stat)
    # check for errors
    if 'error' in metadata:
        return metadata
    # extract video info from streams
    videostream = False
    for stream in metadata['streams']:
        if stream['codec_type'] == 'video':
            videostream = True
            bitrate = int(stream['bit_rate']) if 'bit_rate' in stream else None
            # format bitrate to kb/s
            if bitrate is not None and bitrateformat:
                bitrate = round(bitrate / 1000, 6)
                bitrate = str(bitrate) + " kb/s"
            duration = float(stream['duration']) if 'duration' in stream else None
            # format duration
            if duration is not None and durationformat:
                duration = str(datetime.timedelta(seconds=duration))
            # format framerate
            try:
                framerate = round(int(stream['nb_frames']) / float(stream['duration']), frameratedecimals) if 'nb_frames' in stream and 'duration' in stream else None
            except ZeroDivisionError:
                framerate = 0
            mediatext = {
                'resolution': str(stream['width']) + 'x' + str(stream['height']) if 'width' in stream and 'height' in stream else None,
                'codec': stream['codec_name'] if 'codec_name' in stream else None,
                'codeclong': stream['codec_long_name'] if 'codec_long_name' in stream else None,
                'codectag': stream['codec_tag_string'] if 'codec_tag_string' in stream else None,
                'pixfmt': stream['pix_fmt'] if 'pix_fmt' in stream else None,
                'frames': int(stream['nb_frames']) if 'nb_frames' in stream else None,
                'duration': duration,
                'framerate': framerate,
                'bitrate': bitrate
            }
            break
    if not videostream:
        mediatext = {'warning': 'no video codec stream'}
    return mediatext


def dir_excluded(path):
    """Return True if path in excludedirs, False if not in the list."""
    # return False if dir exclude list is empty
    if not excludedirs:
        return False
    name = os.path.basename(path)
    # skip any dirs in excludedirs
    if name in excludedirs or path in excludedirs:
        return True
    # skip any dirs that are found in reg exp checks including wildcard searches
    for d in excludedirs:        
        if d.startswith('*'):
            d = d.lstrip('*')
            
        if d.endswith('/'):
            d = d.rstrip('/')
        
        try:
            res = re.search(d, name)
        except re.error as e:
            raise Exception(e)
        else:
            if res:
                return True
            
        try:
            res = re.search(d, path)
        except re.error as e:
            raise Exception(e)
        else:
            if res:
                return True
    return False


def add_mappings(mappings):
    """Returns a dict with additional es mappings."""
    mappings['mappings']['properties'].update({
        'media_info': {
            'type': 'object',
            'properties': {
                'resolution': {
                    'type': 'keyword',
                            'fields': {
                                'text': {
                                    'type': 'text'
                                }
                            }
                },
                'codec': {
                    'type': 'keyword',
                            'fields': {
                                'text': {
                                    'type': 'text'
                                }
                            }
                },
                'codeclong': {
                    'type': 'keyword',
                            'fields': {
                                'text': {
                                    'type': 'text'
                                }
                            }
                },
                'codectag': {
                    'type': 'keyword',
                            'fields': {
                                'text': {
                                    'type': 'text'
                                }
                            }
                },
                'pixfmt': {
                    'type': 'keyword',
                            'fields': {
                                'text': {
                                    'type': 'text'
                                }
                            }
                },
                'frames': { 'type': 'integer' },
                'framerate': { 'type': 'float' }
            }
        }
    })
    if bitrateformat:
        mappings['mappings']['properties']['media_info']['properties'].update({
            'bitrate': {
                    'type': 'keyword',
                            'fields': {
                                'text': {
                                    'type': 'text'
                                }
                            }
                }
        })
    else:
        mappings['mappings']['properties']['media_info']['properties'].update({
            'bitrate': { 'type': 'long' }
        })
    if durationformat:
        mappings['mappings']['properties']['media_info']['properties'].update({
            'duration': {
                    'type': 'keyword',
                            'fields': {
                                'text': {
                                    'type': 'text'
                                }
                            }
                }
        })
    else:
        mappings['mappings']['properties']['media_info']['properties'].update({
            'duration': { 'type': 'float' }
        })
    return mappings


def add_meta(path, osstat):
    """Returns a dict with additional file meta data.
    For any warnings or errors, raise RuntimeWarning or RuntimeError.
    RuntimeWarning and RuntimeError requires two args, error message string and dict or None."""
    # skip excluded dirs
    if dir_excluded(path):
        if verbose:
            mipluglogger.info('Skipping excluded directory {0}'.format(path))
        return None
    extension = os.path.splitext(os.path.basename(path))[1][1:].lower()
    if extension in extensions:
        if verbose:
            mipluglogger.info('Getting media info for {0}...'.format(path))
        start = time.time()
        info = get_media_info(path, osstat)
        end = time.time()
        elapsed = round(end - start, 5)
        if verbose:
            mipluglogger.info('Finished getting media info for {0} in {1} sec'.format(path, elapsed))
        return {'media_info': info}
    return None


def add_tags(metadict):
    """Returns a dict with additional tag data or return None to not alter tags."""
    # check if bad video file and add extra tags
    if 'media_info' in metadict and 'error' in metadict['media_info']:
        newtags = ['mediainfo-plugin', 'bad-video']
        if 'tags' in metadict:
            return {'tags': metadict['tags'] + newtags}
        else:
            return {'tags': newtags}
    return None


def for_type(doc_type):
    """Determine if this plugin should run for file and/or directory."""
    if doc_type in ('file'):
        return True
    return False


def init(diskover_globals):
    """Initialize the plugin.
    Called by diskover when the plugin is first loaded.
    """
    global micache
    global mipluglogger
    global mipluglogger_warn
    
    # license check
    # DO NOT ALTER, REMOVE THIS CODE OR COMMENT IT OUT.
    # REMOVING THE LICENSE CHECK VIOLATES THE LICENSE AGREEMENT AND IS AN ILLEGAL OFFENCE.
    lic = diskover_lic.License()
    lic.check_license()
    diskover_lic.licfc(lic, 'ME', __name__)
    
    # Setup logging
    mipluglogger = logging.getLogger(__name__)
    mipluglogger_warn = logging.getLogger(__name__ + '_warn')
    if diskover_globals['logtofile']:
        mipluglogger.setLevel(diskover_globals['loglevel'])
        mipluglogger.addHandler(diskover_globals['handler_file'])
        # console logging
        mipluglogger.addHandler(diskover_globals['handler_con'])
        # warnings log
        mipluglogger_warn.setLevel(logging.WARN)
        mipluglogger_warn.addHandler(diskover_globals['handler_warnfile'])
    
    # Check for ffprobe command in path
    cmd = 'ffprobe'
    if shutil.which(cmd) is None:
        mipluglogger.critical('ffprobe command not found in path!')
        sys.exit(1)
    
    # Setup media info cache db
    try:
        toppaths = diskover_globals['tree_dirs']
        toppaths_hash = hashlib.md5(" ".join(toppaths).encode('utf-8')).hexdigest()
        cachedir_abspath = os.path.abspath(os.path.join(cachedir, toppaths_hash))
        micache = mi_cache.cache(cachedir_abspath)
    except FileExistsError:
        pass
    except OSError as e:
        mipluglogger.error('Error creating media info cache directory {0}'.format(e))
        sys.exit(1)
    return


def close(diskover_globals):
    """Close the plugin.
    Called by diskover at end of crawl.
    """
    micache.close_db()
    return