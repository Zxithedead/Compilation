#!/usr/bin/env python3

"""
diskover
https://diskoverdata.com

Copyright 2017-2021 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/

All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/

Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

diskover xytech asset plugin
"""

import urllib3.exceptions
from suds.client import Client
import requests
import uuid

import yaml
import logging

from datetime import datetime

from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk

CONFIG_PATH = "/root/.config/diskover_xytech_asset/config.yaml"


def add_mappings(es, index):
    mapping = {
        "properties": {
            "xytech": {
                "type": "object",
                "properties": {
                    "asset_id": {
                        "type": "keyword"
                    }
                }
            }
        }
    }

    es.indices.put_mapping(body=mapping, index=index)


def get_assets(config, endpoint):
    logging.info("--- Retrieving assets from Diskover...")

    result = requests.get("{}/api.php/{}/search?query=type:file&size=10000".format(
        config["DiskoverEndpoint"],
        endpoint
    ))
    data = result.json()

    assets_raw = data["message"]["data"]
    assets = []

    for asset in assets_raw:
        if "xytech" not in asset["_source"] or "asset_id" not in asset["_source"]["xytech"] or asset["_source"]["xytech"]["asset_id"] is "":
            assets.append({
                "doc_id": asset["_id"],
                "name": asset["_source"]["name"],
                "path": "{}/{}".format(asset["_source"]["parent_path"], asset["_source"]["name"]),
                "customer_id": asset["_source"]["parent_path"].split('/')[-1].split("_")[0]
            })

    logging.debug("Got assets: {}".format(assets))

    return assets


def create_media_assets(assets, config):
    logging.info("--- Creating Xytech assets...")

    client = Client("file://{}".format(config["MPWSDLAbsolutePath"]))
    xytech_assets = []

    RowAction = client.factory.create("ns0:RowAction")

    credentials = client.factory.create("ns0:Credentials")
    credentials.DBName = config["MPDBName"]
    credentials.UserID = config["MPUserID"]
    credentials.Password = config["MPPassword"]

    for asset in assets:
        logging.info("Computing: {}".format(asset["name"]))

        external_key = str(uuid.uuid1())

        array_of_lib_master_data_set_lib_master_row = client.factory.create("ns1:ArrayOfLibMasterDataSet_lib_master_Row")

        lib_master_data_set = client.factory.create("ns1:LibMasterDataSet")
        lib_master_data_set.lib_master_Rows = array_of_lib_master_data_set_lib_master_row

        lib_master_row_key = client.factory.create("ns1:LibMaster_lib_master_RowKey")
        lib_master_row_key.external_key = external_key

        lib_asset_type_lib_asset_type_row_key = client.factory.create("ns1:LibAssetType_lib_asset_type_RowKey")
        lib_asset_type_lib_asset_type_row_key.asset_type_desc = "File"

        sys_address_doc_key = client.factory.create("ns1:SysAddressDocKey")
        sys_address_doc_key.list_id = asset["customer_id"]

        stk_format_stk_format_row_key = client.factory.create("ns1:StkFormat_stk_format_RowKey")
        stk_format_stk_format_row_key.format_no = 84

        lib_master_data_set_lib_master_title_row = client.factory.create("ns1:LibMasterDataSet_lib_master_title_Row")
        lib_master_data_set_lib_master_title_row.title = asset["name"]

        array_of_lib_master_data_set_lib_master_title_row = client.factory.create("ns1:ArrayOfLibMasterDataSet_lib_master_title_Row")
        array_of_lib_master_data_set_lib_master_title_row.lib_master_title_Row.append(lib_master_data_set_lib_master_title_row)

        lib_master_data_set_lib_master_row = client.factory.create("ns1:LibMasterDataSet_lib_master_Row")
        lib_master_data_set_lib_master_row.api_row_action = RowAction.Insert
        lib_master_data_set_lib_master_row.key = lib_master_row_key
        lib_master_data_set_lib_master_row.external_key = external_key
        lib_master_data_set_lib_master_row.master_desc = ""
        lib_master_data_set_lib_master_row.active = "Y"
        lib_master_data_set_lib_master_row.asset_type_no = lib_asset_type_lib_asset_type_row_key
        lib_master_data_set_lib_master_row.asset_title = asset["name"]
        lib_master_data_set_lib_master_row.cust_id = sys_address_doc_key
        lib_master_data_set_lib_master_row.format_no = stk_format_stk_format_row_key
        lib_master_data_set_lib_master_row.partition_id = "1"
        lib_master_data_set_lib_master_row.lib_mstr_file_storage_sys_path = asset["path"]
        lib_master_data_set_lib_master_row.lib_master_title_Rows = array_of_lib_master_data_set_lib_master_title_row

        lib_master_data_set.lib_master_Rows.lib_master_Row.append(lib_master_data_set_lib_master_row)

        xy_data_set_container = client.factory.create("ns0:XyDataSetContainer")
        xy_data_set_container.DataSet = lib_master_data_set

        array_of_api_save_argument = client.factory.create("ns0:ArrayOfAPISaveArgument")

        api_save_argument = client.factory.create("ns0:APISaveArgument")
        api_save_argument.ClassName = "LibMaster"
        api_save_argument.ChangeSetContainer = xy_data_set_container
        api_save_argument.KeyName = "external_key"
        api_save_argument.Key = external_key
        api_save_argument.WantNewDoc = True

        array_of_api_save_argument.APISaveArgument.append(api_save_argument)

        result = client.service.Create(credentials, array_of_api_save_argument)

        if result.results is not None:
            xytech_assets.append({
                "asset": asset,
                "xytech_id": result.results.APISaveReturn[0].NewDocDataContainer.DataSet.lib_master_Rows.lib_master_Row[0].master_no
            })
        else:
            logging.warning("Skipping {} because: {}".format(asset["name"], result.CreateResult.Message))

    return xytech_assets


def generate_bulk(assets, index):
    for asset in assets:
        yield {
            '_op_type': 'update',
            '_index': index,
            '_id': asset["asset"]["doc_id"],
            'doc': {'xytech': {"asset_id": asset["xytech_id"]}}
        }


def update_fields(es, index, assets):
    logging.info("--- Adding xytech fields to assets in Diskover...")

    bulk(es, index=index, actions=generate_bulk(assets, index))


def get_endpoint(config):
    logging.info('--- Getting latest endpoint...')

    try:
        result = requests.get("{}/api.php/latest?toppath={}".format(config["DiskoverEndpoint"], config["TopPath"]))
        endpoint = result.json()["message"]["data"]

        logging.info("Working on {}".format(endpoint))
    except (requests.exceptions.ConnectionError, urllib3.exceptions.NewConnectionError, urllib3.exceptions.MaxRetryError) as err:
        logging.error("Error while connecting to Diskover: {}".format(err))
        exit(1)

    return endpoint


def start():
    with open(CONFIG_PATH, "r") as stream:
        try:
            config = yaml.safe_load(stream)
        except yaml.YAMLError as err:
            logging.error("Error while parsing configuration: {}".format(err))
            exit(1)

    numeric_level = getattr(logging, config["LogLevel"].upper(), None)
    if not isinstance(numeric_level, int):
        raise ValueError('Invalid log level: %s'.format(config["LogLevel"]))

    log_path = config["LogPath"]

    if log_path.endswith("/"):
        log_path = log_path[:-1]

    now = datetime.now()

    filename = None

    if config["LogToFile"] is True:
        filename = "{}/output-{}.log".format(log_path, now.strftime("%d-%m-%Y-%H-%M-%S"))

    logging.basicConfig(filename=filename, filemode="w", format="%(asctime)s %(levelname)-8s %(message)s", datefmt="%m/%d/%Y %H:%M:%S", level=numeric_level)

    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(levelname)-8s %(message)s')
    console.setFormatter(formatter)
    logging.getLogger('').addHandler(console)

    logging.info("--- Starting script...")

    with open(CONFIG_PATH, "r") as stream:
        try:
            config = yaml.safe_load(stream)
        except yaml.YAMLError as err:
            logging.error("Error while parsing configuration: {}".format(err))
            exit(1)

    es = Elasticsearch(hosts=[config["ESEndpoint"]])

    logging.debug("Configuration: {}".format(config))

    index = get_endpoint(config)

    add_mappings(es, index)

    assets = get_assets(config, index)

    if len(assets) > 0:
        xytech_assets = create_media_assets(assets, config)
        update_fields(es, index, xytech_assets)


if __name__ == "__main__":
    start()
