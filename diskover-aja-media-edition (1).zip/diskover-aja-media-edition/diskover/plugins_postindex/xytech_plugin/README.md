# Installing Diskover Xytech asset plugin

## Folder stucture

You can put `diskover-xytech-asset.py` and `wsdl/` inside `/opt/diskover/plugins_postindex/xytech_plugin/` folder.
If you want to change the location of these files, just keep in mind that you have to change MPWSDLAbsolutePath inside the `config.yaml` to the new location of `wsdl/XytechAPI.wsdl`.

The `config.yaml` file can stand anywhere, but you have to modify the constant `CONFIG_PATH` inside `diskover-xytech-asset.py`. By default it should be located in `/root/.config/diskover_xytech_asset/config.yaml`.

## Configuration

```yaml
# The diskover API endpoint
DiskoverEndpoint: "http://localhost:8000"

# The ElasticSearch endpoint
ESEndpoint: "http://elasticsearch:9200"

# Mediapulse credentials
MPDBName: ""
MPUserID: ""
MPPassword: ""

# Mediapulse WSDL file ABSOLUTE path
MPWSDLAbsolutePath: "/opt/diskover/plugins_postindex/xytech_plugin/wsdl/XytechAPI.wsdl"

# The Diskover top path to work on
TopPath: "/dps-offload"

# Whether to activate logging or not
LogToFile: True
LogPath: "./"
# Can be DEBUG, INFO, WARNING, ERROR, CRITICAL
LogLevel: INFO
```
